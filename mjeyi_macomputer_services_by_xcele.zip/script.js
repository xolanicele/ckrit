document.getElementById('personal-info-form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent the default form submission

  // Collect form data
  const formData = new FormData(this);
  const data = {};
  formData.forEach((value, key) => {
    data[key] = value;
  });

  // Show the modal
  const modal = document.getElementById("infoModal");
  modal.style.display = "block";

  // Generate and display report
  displayReport(data);

  // Simulate credit score increase
  const creditScoreBar = document.getElementById('credit-score-bar');
  creditScoreBar.style.height = '80%'; // Adjust percentage as needed

  // Close the modal
  const closeBtn = document.getElementsByClassName("close")[0];
  closeBtn.onclick = function() {
    modal.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
});

function displayReport(data) {
  const reportContainer = document.getElementById('report-container');
  reportContainer.innerHTML = ''; // Clear previous content

  for (const key in data) {
    if (data[key]) { // Only display non-empty values
      const reportItem = document.createElement('div');
      reportItem.classList.add('report-item');

      const label = document.createElement('div');
      label.classList.add('report-label');
      label.textContent = key.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + ':'; // Format label

      const value = document.createElement('div');
      value.classList.add('report-value');
      value.textContent = data[key];

      reportItem.appendChild(label);
      reportItem.appendChild(value);
      reportContainer.appendChild(reportItem);
    }
  }

  // Display companies to settle accounts with
  const companyListData = JSON.parse(localStorage.getItem('companies')) || [];
  companyListData.forEach(company => {
    const reportItem = document.createElement('div');
    reportItem.classList.add('report-item');

    const label = document.createElement('div');
    label.classList.add('report-label');
    label.textContent = company.name + ':'; // Company name as label

    const value = document.createElement('div');
    value.classList.add('report-value');
    value.textContent = 'ZAR ' + company.amount; // Amount as value

    reportItem.appendChild(label);
    reportItem.appendChild(value);
    reportContainer.appendChild(reportItem);
  });
}

// Placeholder function to simulate fetching credit report data
async function fetchCreditReport() {
  // In a real application, this function would call APIs from TransUnion, XDS, Debicheck, and ClearScore.
  // Due to the sensitive nature and the need for API keys, this is a placeholder.

  // Simulate API response
  const simulatedData = {
    transunion: { score: 680, status: 'Good' },
    xds: { score: 720, status: 'Excellent' },
    debicheck: { status: 'Clear' },
    clearscore: { score: 450, status: 'Fair' }
  };

  // Display the simulated data
  const creditReportDataElement = document.getElementById('credit-report-data');
  creditReportDataElement.innerHTML = `
    <h3>Simulated Credit Report Data:</h3>
    <p><strong>TransUnion:</strong> Score: ${simulatedData.transunion.score}, Status: ${simulatedData.transunion.status}</p>
    <p><strong>XDS:</strong> Score: ${simulatedData.xds.score}, Status: ${simulatedData.xds.status}</p>
    <p><strong>Debicheck:</strong> Status: ${simulatedData.debicheck.status}</p>
    <p><strong>ClearScore:</strong> Score: ${simulatedData.clearscore.score}, Status: ${simulatedData.clearscore.status}</p>
  `;
}

// Call the fetchCreditReport function when the page loads
window.onload = fetchCreditReport;

document.addEventListener('DOMContentLoaded', function() {
  const addCompanyButton = document.getElementById('add-company');
  const companyList = document.getElementById('company-list');
  const newCompanyInput = document.getElementById('new-company');
  const companySelector = document.getElementById('company-selector');

  // Load companies from local storage
  let companies = JSON.parse(localStorage.getItem('companies')) || [];
  renderCompanyList();

  addCompanyButton.addEventListener('click', function() {
    let companyName = newCompanyInput.value.trim();
    if (companySelector.value) {
      companyName = companySelector.value;
    }
    if (companyName !== '') {
      const listItem = document.createElement('li');
      const companyAmount = parseFloat(listItem.querySelector('.company-amount')?.value) || 0; // Default to 0 if no amount is entered

      //check for duplicate
      const existingCompanyIndex = companies.findIndex(c => c.name === companyName);
      if (existingCompanyIndex > -1) {
        alert('Company already exists in the list.');
        return;
      }

      listItem.innerHTML = `
        <span>${companyName}</span>
        <input type="number" class="company-amount" placeholder="Amount (ZAR)">
        <button type="button" class="remove-company">Remove</button>
      `;
      companyList.appendChild(listItem);
      newCompanyInput.value = ''; // Clear the input
      companySelector.value = ''; // Clear the selector

      // Add event listener to the remove button
      const removeButton = listItem.querySelector('.remove-company');
      removeButton.addEventListener('click', function() {
        const companyName = listItem.querySelector('span').textContent;
        companies = companies.filter(c => c.name !== companyName);
        localStorage.setItem('companies', JSON.stringify(companies));
        listItem.remove();
      });

      // Save company to local storage
      const amountInput = listItem.querySelector('.company-amount');
      amountInput.addEventListener('change', function() {
        const amount = parseFloat(amountInput.value) || 0;
        const company = { name: companyName, amount: amount };
        const existingCompanyIndex = companies.findIndex(c => c.name === company.name);
        if (existingCompanyIndex > -1) {
          companies[existingCompanyIndex] = company;
        } else {
          companies.push(company);
        }
        localStorage.setItem('companies', JSON.stringify(companies));
      });

      companies.push({ name: companyName, amount: 0 });
      localStorage.setItem('companies', JSON.stringify(companies));
      renderCompanyList();

    }
  });

  function renderCompanyList() {
    companyList.innerHTML = '';
    companies.forEach(company => {
      const listItem = document.createElement('li');
      listItem.innerHTML = `
        <span>${company.name}</span>
        <input type="number" class="company-amount" placeholder="Amount (ZAR)" value="${company.amount}">
        <button type="button" class="remove-company">Remove</button>
      `;
      companyList.appendChild(listItem);

      const removeButton = listItem.querySelector('.remove-company');
      removeButton.addEventListener('click', function() {
        companies = companies.filter(c => c.name !== company.name);
        localStorage.setItem('companies', JSON.stringify(companies));
        renderCompanyList();
      });

      const amountInput = listItem.querySelector('.company-amount');
      amountInput.addEventListener('change', function() {
        company.amount = parseFloat(amountInput.value) || 0;
        localStorage.setItem('companies', JSON.stringify(companies));
      });
    });
  }

  // Call the render function
  renderCompanyList();
});