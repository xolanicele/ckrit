"use server"

import type { Channel, M3UItem } from "./types"
import { parse } from "iptv-playlist-parser"
import { v4 as uuidv4 } from "uuid"

// GitHub IPTV repository URL
const IPTV_PLAYLIST_URL = "https://iptv-org.github.io/iptv/index.m3u"
const COUNTRY_CODES_URL = "https://iptv-org.github.io/iptv/countries.json"

// Cache the channels to avoid fetching them on every request
let cachedChannels: Channel[] | null = null
let lastFetchTime = 0
const CACHE_DURATION = 1000 * 60 * 60 // 1 hour

interface CountryInfo {
  name: string
  code: string
  languages: string[]
}

export async function fetchChannels(): Promise<Channel[]> {
  // Return cached channels if available and not expired
  const now = Date.now()
  if (cachedChannels && now - lastFetchTime < CACHE_DURATION) {
    return cachedChannels
  }

  try {
    // Fetch country codes for mapping
    const countryCodesResponse = await fetch(COUNTRY_CODES_URL, {
      next: { revalidate: 3600 },
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })
    const countryCodes: CountryInfo[] = await countryCodesResponse.json()

    // Create a map for quick lookup
    const countryMap = new Map<string, string>()
    countryCodes.forEach((country) => {
      countryMap.set(country.code.toLowerCase(), country.name)
    })

    // Fetch the M3U playlist
    const response = await fetch(IPTV_PLAYLIST_URL, {
      next: { revalidate: 3600 },
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })
    const m3uContent = await response.text()

    // Parse the M3U playlist
    const playlist = parse(m3uContent)

    // Convert M3U items to Channel objects and check if they're active
    const channelPromises = playlist.items.map(async (item: M3UItem) => {
      const countryCode = item.tvg.id?.split(".").pop() || ""
      const country = countryMap.get(countryCode) || ""

      return {
        id: uuidv4(),
        name: item.name,
        url: item.url,
        logo: item.tvg.logo,
        category: item.group.title,
        country: country,
        language: "", // Could be extracted if available
        isActive: await checkChannelStatus(item.url),
      }
    })

    // Process channels in batches to avoid overwhelming the server
    const batchSize = 50
    const channels: Channel[] = []

    for (let i = 0; i < channelPromises.length; i += batchSize) {
      const batch = channelPromises.slice(i, i + batchSize)
      const results = await Promise.all(batch)
      channels.push(...results)
    }

    // Filter out inactive channels
    const activeChannels = channels.filter((channel) => channel.isActive)

    // Update cache
    cachedChannels = activeChannels
    lastFetchTime = now

    return activeChannels
  } catch (error) {
    console.error("Error fetching IPTV channels:", error)
    return []
  }
}

async function checkChannelStatus(url: string): Promise<boolean> {
  try {
    // Attempt to fetch the stream with a HEAD request and a timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    const response = await fetch(url, {
      method: "HEAD",
      signal: controller.signal,
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })

    clearTimeout(timeoutId)

    // Consider 2xx status codes as active
    return response.ok
  } catch (error) {
    // Any error means the channel is not active
    return false
  }
}
