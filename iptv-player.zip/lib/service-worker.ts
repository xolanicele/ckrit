"use client"

export async function registerServiceWorker() {
  if (typeof window !== "undefined" && "serviceWorker" in navigator) {
    try {
      // Create a simple service worker for caching
      const swCode = `
        const CACHE_NAME = 'mjeyi-iptv-cache-v1';
        const STREAM_CACHE_NAME = 'mjeyi-iptv-stream-cache-v1';
        
        // Cache static assets
        self.addEventListener('install', (event) => {
          event.waitUntil(
            caches.open(CACHE_NAME).then((cache) => {
              return cache.addAll([
                '/',
                '/index.html',
                '/favicon.ico'
              ]);
            })
          );
        });
        
        // Network-first strategy for stream segments
        self.addEventListener('fetch', (event) => {
          const url = new URL(event.request.url);
          
          // Special handling for m3u8 and ts files (stream segments)
          if (url.pathname.endsWith('.m3u8') || url.pathname.endsWith('.ts')) {
            event.respondWith(
              fetch(event.request)
                .then((response) => {
                  // Clone the response to store in cache
                  const responseToCache = response.clone();
                  
                  caches.open(STREAM_CACHE_NAME).then((cache) => {
                    cache.put(event.request, responseToCache);
                  });
                  
                  return response;
                })
                .catch(() => {
                  // If network fails, try to get from cache
                  return caches.match(event.request);
                })
            );
          } else {
            // Standard cache-first strategy for other assets
            event.respondWith(
              caches.match(event.request).then((response) => {
                return response || fetch(event.request).then((fetchResponse) => {
                  return caches.open(CACHE_NAME).then((cache) => {
                    cache.put(event.request, fetchResponse.clone());
                    return fetchResponse;
                  });
                });
              })
            );
          }
        });
        
        // Clean up old caches
        self.addEventListener('activate', (event) => {
          const cacheWhitelist = [CACHE_NAME, STREAM_CACHE_NAME];
          
          event.waitUntil(
            caches.keys().then((cacheNames) => {
              return Promise.all(
                cacheNames.map((cacheName) => {
                  if (cacheWhitelist.indexOf(cacheName) === -1) {
                    return caches.delete(cacheName);
                  }
                })
              );
            })
          );
        });
      `

      // Create a Blob containing the service worker code
      const blob = new Blob([swCode], { type: "text/javascript" })
      const swUrl = URL.createObjectURL(blob)

      // Register the service worker
      await navigator.serviceWorker.register(swUrl, { scope: "/" })
      console.log("Service worker registered successfully")

      // Clean up the object URL
      URL.revokeObjectURL(swUrl)

      return true
    } catch (error) {
      console.error("Service worker registration failed:", error)
      return false
    }
  }

  return false
}
