export interface Channel {
  id: string
  name: string
  url: string
  logo?: string
  category?: string
  country?: string
  language?: string
  isActive: boolean
}

export interface M3UItem {
  name: string
  tvg: {
    id?: string
    name?: string
    logo?: string
    url?: string
    rec?: string
  }
  group: {
    title?: string
  }
  http: {
    referrer?: string
    "user-agent"?: string
  }
  url: string
  raw: string
  timeshift?: string
  catchup?: {
    type?: string
    days?: string
    source?: string
  }
}

export interface HistoryItem {
  channelId: string
  name: string
  timestamp: string
}

export interface UserPreferences {
  theme: string
  volume: number
  quality: string
  favorites: string[]
  history: HistoryItem[]
  lastChannel: string | null
  enablePiP?: boolean
  enableAdvancedBuffering?: boolean
}
