import IPTVPlayer from "@/components/iptv-player"
import { Suspense } from "react"
import LoadingScreen from "@/components/loading-screen"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black text-white">
      <Suspense fallback={<LoadingScreen />}>
        <IPTVPlayer />
      </Suspense>
    </main>
  )
}
