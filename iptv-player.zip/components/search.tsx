"use client"

import type React from "react"
import { Input } from "@/components/ui/input"
import { SearchIcon } from "lucide-react"
import { motion } from "framer-motion"

interface SearchProps {
  placeholder?: string
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export function Search({ placeholder, value, onChange }: SearchProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 300 }}
      className="relative"
    >
      <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
      <Input
        type="search"
        placeholder={placeholder || "Search..."}
        className="pl-10 bg-zinc-900 border-zinc-800 focus:ring-purple-500 focus:border-purple-500"
        value={value}
        onChange={onChange}
      />
    </motion.div>
  )
}
