"use client"

import { Moon, Sun, Monitor } from "lucide-react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface ThemeSelectorProps {
  theme: string
  onChange: (theme: string) => void
}

export default function ThemeSelector({ theme, onChange }: ThemeSelectorProps) {
  const themes = [
    { id: "light", icon: Sun, label: "Light" },
    { id: "dark", icon: Moon, label: "Dark" },
    { id: "system", icon: Monitor, label: "System" },
  ]

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-zinc-400">Theme</h3>
      <div className="grid grid-cols-3 gap-2">
        {themes.map(({ id, icon: Icon, label }) => (
          <motion.button
            key={id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onChange(id)}
            className={cn(
              "flex flex-col items-center justify-center p-3 rounded-md border border-zinc-800 transition-colors",
              theme === id ? "bg-purple-500/20 border-purple-500" : "bg-zinc-900 hover:bg-zinc-800",
            )}
          >
            <Icon className={cn("h-5 w-5 mb-1", theme === id ? "text-purple-500" : "text-zinc-400")} />
            <span className="text-xs">{label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  )
}
