"use client"

import { useEffect, useRef, useState } from "react"
import type { Channel } from "@/lib/types"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Loader2,
  Heart,
  PictureInPicture,
  SkipForward,
  RotateCcw,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useToast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface VideoPlayerProps {
  channel: Channel
  volume: number
  onVolumeChange: (volume: number) => void
  isFavorite: boolean
  onToggleFavorite: () => void
}

export default function VideoPlayer({
  channel,
  volume,
  onVolumeChange,
  isFavorite,
  onToggleFavorite,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [currentQuality, setCurrentQuality] = useState<string>("auto")
  const [bufferingProgress, setBufferingProgress] = useState(0)
  const [isBuffering, setIsBuffering] = useState(false)
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const { toast } = useToast()

  // Handle channel change
  useEffect(() => {
    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)
    setIsBuffering(false)

    if (videoRef.current) {
      videoRef.current.load()
    }

    // Simulate advanced buffering with progress
    const bufferInterval = setInterval(() => {
      if (isLoading) {
        setBufferingProgress((prev) => {
          const newProgress = prev + Math.random() * 10
          return newProgress > 100 ? 100 : newProgress
        })
      }
    }, 200)

    return () => clearInterval(bufferInterval)
  }, [channel])

  // Apply volume from props
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume
    }
  }, [volume])

  // Auto-hide controls
  useEffect(() => {
    const hideControls = () => {
      if (isPlaying && !isBuffering) {
        setShowControls(false)
      }
    }

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }

    if (showControls) {
      controlsTimeoutRef.current = setTimeout(hideControls, 3000)
    }

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }
    }
  }, [showControls, isPlaying, isBuffering])

  // Handle fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Implement advanced buffering
  useEffect(() => {
    if (!videoRef.current) return

    const handleWaiting = () => {
      setIsBuffering(true)
      // Implement advanced buffering logic
      if (videoRef.current) {
        // Try to preload more of the video
        videoRef.current.preload = "auto"
      }
    }

    const handlePlaying = () => {
      setIsBuffering(false)
    }

    const video = videoRef.current
    video.addEventListener("waiting", handleWaiting)
    video.addEventListener("playing", handlePlaying)

    return () => {
      video.removeEventListener("waiting", handleWaiting)
      video.removeEventListener("playing", handlePlaying)
    }
  }, [])

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play().catch((err) => {
          setError("Failed to play this stream. It may be unavailable.")
          console.error("Play error:", err)
          toast({
            title: "Playback Error",
            description: "Failed to play this stream. It may be unavailable.",
            variant: "destructive",
          })
        })
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    if (videoRef.current) {
      videoRef.current.volume = newVolume
    }
    onVolumeChange(newVolume)
  }

  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (document.fullscreenElement) {
      document.exitFullscreen()
    } else {
      containerRef.current.requestFullscreen()
    }
  }

  const togglePictureInPicture = async () => {
    if (!videoRef.current) return

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture()
      } else {
        await videoRef.current.requestPictureInPicture()
        toast({
          title: "Picture-in-Picture mode",
          description: "You can now browse while watching",
          duration: 3000,
        })
      }
    } catch (error) {
      console.error("PiP error:", error)
      toast({
        title: "Feature not supported",
        description: "Picture-in-Picture is not supported in your browser",
        variant: "destructive",
      })
    }
  }

  const reloadStream = () => {
    if (!videoRef.current) return

    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)

    // Force reload the video element
    const currentTime = videoRef.current.currentTime
    videoRef.current.load()
    videoRef.current.currentTime = currentTime

    if (isPlaying) {
      videoRef.current.play().catch((err) => {
        console.error("Reload error:", err)
        setError("Failed to reload stream")
      })
    }

    toast({
      title: "Reloading stream",
      description: "Attempting to refresh the connection",
      duration: 2000,
    })
  }

  const skipForward = () => {
    if (!videoRef.current) return

    // For live streams, this might not do much, but for VOD content it would
    videoRef.current.currentTime += 10
    toast({
      title: "Skipped forward",
      description: "+10 seconds",
      duration: 1000,
    })
  }

  const changeQuality = (quality: string) => {
    setCurrentQuality(quality)
    // In a real implementation, this would switch to a different stream URL
    // For this demo, we'll just show a toast
    toast({
      title: "Quality changed",
      description: `Switched to ${quality} quality`,
      duration: 2000,
    })
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full flex flex-col bg-black"
      onMouseMove={() => {
        setShowControls(true)
        if (controlsTimeoutRef.current) {
          clearTimeout(controlsTimeoutRef.current)
        }
        controlsTimeoutRef.current = setTimeout(() => {
          if (isPlaying && !isBuffering) {
            setShowControls(false)
          }
        }, 3000)
      }}
    >
      <div className="relative flex-1 bg-black">
        <AnimatePresence>
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70 z-10"
            >
              <Loader2 className="w-12 h-12 animate-spin text-purple-500" />
              <div className="mt-4 w-64 bg-zinc-800 rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  initial={{ width: "0%" }}
                  animate={{ width: `${bufferingProgress}%` }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                />
              </div>
              <p className="mt-2 text-sm text-zinc-400">Buffering stream...</p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-80 z-10"
            >
              <div className="text-center p-6 bg-zinc-900/80 backdrop-blur-md rounded-lg max-w-md">
                <p className="text-red-500 text-xl mb-4">{error}</p>
                <div className="flex gap-2 justify-center">
                  <Button onClick={reloadStream} className="flex items-center gap-2">
                    <RotateCcw className="w-4 h-4" />
                    Try Again
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          autoPlay
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onLoadStart={() => setIsLoading(true)}
          onCanPlay={() => setIsLoading(false)}
          onError={() => {
            setIsLoading(false)
            setError("This stream is currently unavailable")
          }}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => setIsBuffering(false)}
        >
          <source src={channel.url} type="application/x-mpegURL" />
          Your browser does not support the video tag.
        </video>

        {/* Channel info overlay */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-zinc-800 rounded overflow-hidden flex-shrink-0">
                  {channel.logo ? (
                    <img
                      src={channel.logo || "/placeholder.svg"}
                      alt={channel.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-bold">
                      {channel.name.substring(0, 2).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-semibold line-clamp-1">{channel.name}</h2>
                  <div className="flex text-sm text-zinc-400 mt-1">
                    {channel.country && <span className="mr-2">{channel.country}</span>}
                    {channel.category && <span>{channel.category}</span>}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onToggleFavorite}
                  className="text-white hover:bg-zinc-800/50"
                >
                  <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Video controls */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent z-10"
            >
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={togglePlay}
                  disabled={isLoading}
                  className="text-white hover:bg-zinc-800/50"
                >
                  {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                </Button>

                <Button variant="ghost" size="icon" onClick={skipForward} className="text-white hover:bg-zinc-800/50">
                  <SkipForward className="h-5 w-5" />
                </Button>

                <Button variant="ghost" size="icon" onClick={toggleMute} className="text-white hover:bg-zinc-800/50">
                  {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </Button>

                <div className="w-24 mx-2">
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    min={0}
                    max={1}
                    step={0.01}
                    onValueChange={handleVolumeChange}
                    className="[&>span:first-child]:h-1.5 [&>span:first-child]:bg-white/30 [&_[role=slider]]:bg-purple-500 [&_[role=slider]]:w-3 [&_[role=slider]]:h-3 [&_[role=slider]]:border-0 [&>span:first-child_span]:bg-purple-500"
                  />
                </div>

                <div className="ml-auto flex items-center gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800/50">
                        <Settings className="h-5 w-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800">
                      <DropdownMenuItem
                        onClick={() => changeQuality("auto")}
                        className={cn(currentQuality === "auto" && "bg-zinc-800")}
                      >
                        Auto Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => changeQuality("high")}
                        className={cn(currentQuality === "high" && "bg-zinc-800")}
                      >
                        High Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => changeQuality("medium")}
                        className={cn(currentQuality === "medium" && "bg-zinc-800")}
                      >
                        Medium Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => changeQuality("low")}
                        className={cn(currentQuality === "low" && "bg-zinc-800")}
                      >
                        Low Quality
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={togglePictureInPicture}
                    className="text-white hover:bg-zinc-800/50"
                  >
                    <PictureInPicture className="h-5 w-5" />
                  </Button>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleFullscreen}
                    className="text-white hover:bg-zinc-800/50"
                  >
                    <Maximize className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Buffering indicator */}
        <AnimatePresence>
          {isBuffering && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-sm p-3 rounded-full"
            >
              <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
