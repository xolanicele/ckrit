"use client"

import { useEffect, useState, useRef } from "react"
import { fetchChannels } from "@/lib/iptv-service"
import ChannelList from "./channel-list"
import VideoPlayer from "./video-player"
import ChannelFilters from "./channel-filters"
import type { Channel, UserPreferences } from "@/lib/types"
import { Search } from "./search"
import { Settings, Menu, X, Heart, Clock, Tv2 } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useMediaQuery } from "@/hooks/use-media-query"
import { cn } from "@/lib/utils"
import ThemeSelector from "./theme-selector"
import WatchHistory from "./watch-history"
import Favorites from "./favorites"
import { registerServiceWorker } from "@/lib/service-worker"
import LoadingScreen from "./loading-screen"

const DEFAULT_PREFERENCES: UserPreferences = {
  theme: "dark",
  volume: 0.8,
  quality: "auto",
  favorites: [],
  history: [],
  lastChannel: null,
}

export default function IPTVPlayer() {
  const [channels, setChannels] = useState<Channel[]>([])
  const [filteredChannels, setFilteredChannels] = useState<Channel[]>([])
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null)
  const [categories, setCategories] = useState<string[]>([])
  const [countries, setCountries] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [selectedCountry, setSelectedCountry] = useState<string>("All")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [loading, setLoading] = useState<boolean>(true)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState("channels")
  const [userPreferences, setUserPreferences] = useState<UserPreferences>(DEFAULT_PREFERENCES)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const { toast } = useToast()
  const isDesktop = useMediaQuery("(min-width: 768px)")
  const playerRef = useRef<HTMLDivElement>(null)

  // Load user preferences from localStorage
  useEffect(() => {
    try {
      const savedPreferences = localStorage.getItem("mjeyi-iptv-preferences")
      if (savedPreferences) {
        const parsedPreferences = JSON.parse(savedPreferences) as UserPreferences
        setUserPreferences(parsedPreferences)

        // Apply saved theme
        document.documentElement.classList.toggle("dark", parsedPreferences.theme === "dark")
      }
    } catch (error) {
      console.error("Failed to load preferences:", error)
    }

    // Register service worker for advanced caching
    registerServiceWorker()
      .then(() => console.log("Service worker registered"))
      .catch((error) => console.error("Service worker registration failed:", error))
  }, [])

  // Save user preferences to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("mjeyi-iptv-preferences", JSON.stringify(userPreferences))
    } catch (error) {
      console.error("Failed to save preferences:", error)
    }
  }, [userPreferences])

  // Set sidebar state based on screen size
  useEffect(() => {
    setSidebarOpen(isDesktop)
  }, [isDesktop])

  useEffect(() => {
    const loadChannels = async () => {
      try {
        setLoading(true)
        const data = await fetchChannels()
        setChannels(data)
        setFilteredChannels(data)

        // Extract unique categories and countries
        const uniqueCategories = ["All", ...new Set(data.map((channel) => channel.category))].filter(Boolean)
        const uniqueCountries = ["All", ...new Set(data.map((channel) => channel.country))].filter(Boolean)

        setCategories(uniqueCategories)
        setCountries(uniqueCountries)

        // Set initial selected channel from preferences or first available
        if (userPreferences.lastChannel) {
          const savedChannel = data.find((c) => c.id === userPreferences.lastChannel)
          if (savedChannel) {
            setSelectedChannel(savedChannel)
            toast({
              title: "Welcome back!",
              description: `Resuming ${savedChannel.name}`,
              duration: 3000,
            })
          } else {
            setSelectedChannel(data[0])
          }
        } else if (data.length > 0) {
          setSelectedChannel(data[0])
        }
      } catch (error) {
        console.error("Failed to load channels:", error)
        toast({
          title: "Error loading channels",
          description: "Please check your connection and try again",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadChannels()
  }, [toast, userPreferences.lastChannel])

  useEffect(() => {
    let result = channels

    // Apply category filter
    if (selectedCategory !== "All") {
      result = result.filter((channel) => channel.category === selectedCategory)
    }

    // Apply country filter
    if (selectedCountry !== "All") {
      result = result.filter((channel) => channel.country === selectedCountry)
    }

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (channel) =>
          channel.name.toLowerCase().includes(query) ||
          (channel.country && channel.country.toLowerCase().includes(query)),
      )
    }

    setFilteredChannels(result)
  }, [channels, selectedCategory, selectedCountry, searchQuery])

  const handleChannelSelect = (channel: Channel) => {
    setSelectedChannel(channel)

    // Update last watched channel
    setUserPreferences((prev) => ({
      ...prev,
      lastChannel: channel.id,
      history: [
        { channelId: channel.id, name: channel.name, timestamp: new Date().toISOString() },
        ...prev.history.filter((h) => h.channelId !== channel.id).slice(0, 19), // Keep last 20 unique channels
      ],
    }))

    // Close sidebar on mobile after selection
    if (!isDesktop) {
      setSidebarOpen(false)
    }
  }

  const toggleFavorite = (channelId: string) => {
    setUserPreferences((prev) => {
      const isFavorite = prev.favorites.includes(channelId)
      return {
        ...prev,
        favorites: isFavorite ? prev.favorites.filter((id) => id !== channelId) : [...prev.favorites, channelId],
      }
    })

    toast({
      title: userPreferences.favorites.includes(channelId) ? "Removed from favorites" : "Added to favorites",
      duration: 2000,
    })
  }

  const clearHistory = () => {
    setUserPreferences((prev) => ({
      ...prev,
      history: [],
    }))
    toast({
      title: "Watch history cleared",
      duration: 2000,
    })
  }

  if (loading) {
    return <LoadingScreen />
  }

  return (
    <div
      ref={playerRef}
      className="flex flex-col h-screen overflow-hidden bg-gradient-to-br from-black via-zinc-900 to-black"
    >
      <header className="bg-black/50 backdrop-blur-md p-4 border-b border-zinc-800/50 flex items-center justify-between z-10">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden mr-2">
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>

          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2"
          >
            <Tv2 className="h-6 w-6 text-purple-500" />
            <h1 className="text-xl md:text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
              Mjeyi&apos;s IPTV Services
            </h1>
          </motion.div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(!isSettingsOpen)} className="relative">
            <Settings className="h-5 w-5" />
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: isSettingsOpen ? 1 : 0 }}
              className="absolute -top-1 -right-1 w-2 h-2 bg-purple-500 rounded-full"
            />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        <AnimatePresence initial={false}>
          {sidebarOpen && (
            <motion.aside
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className={cn(
                "w-full md:w-80 bg-black/50 backdrop-blur-md border-r border-zinc-800/50 flex flex-col z-20",
                !isDesktop && "absolute inset-y-0 left-0 h-full",
              )}
            >
              <div className="p-4 border-b border-zinc-800/50">
                <Search
                  placeholder="Search channels..."
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                />
              </div>

              <Tabs
                defaultValue="channels"
                value={activeTab}
                onValueChange={setActiveTab}
                className="flex-1 flex flex-col"
              >
                <TabsList className="grid grid-cols-3 mx-4 mt-2">
                  <TabsTrigger value="channels" className="flex items-center gap-1">
                    <Tv2 className="h-4 w-4" />
                    <span className="hidden sm:inline">Channels</span>
                  </TabsTrigger>
                  <TabsTrigger value="favorites" className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    <span className="hidden sm:inline">Favorites</span>
                  </TabsTrigger>
                  <TabsTrigger value="history" className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span className="hidden sm:inline">History</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="channels" className="flex-1 flex flex-col overflow-hidden">
                  <ChannelFilters
                    categories={categories}
                    countries={countries}
                    selectedCategory={selectedCategory}
                    selectedCountry={selectedCountry}
                    onCategoryChange={setSelectedCategory}
                    onCountryChange={setSelectedCountry}
                  />

                  <div className="flex-1 overflow-y-auto">
                    <ChannelList
                      channels={filteredChannels}
                      selectedChannel={selectedChannel}
                      onChannelSelect={handleChannelSelect}
                      favorites={userPreferences.favorites}
                      onToggleFavorite={toggleFavorite}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="favorites" className="flex-1 overflow-hidden">
                  <Favorites
                    channels={channels}
                    favorites={userPreferences.favorites}
                    onChannelSelect={handleChannelSelect}
                    onToggleFavorite={toggleFavorite}
                    selectedChannel={selectedChannel}
                  />
                </TabsContent>

                <TabsContent value="history" className="flex-1 overflow-hidden">
                  <WatchHistory
                    history={userPreferences.history}
                    channels={channels}
                    onChannelSelect={handleChannelSelect}
                    onClearHistory={clearHistory}
                  />
                </TabsContent>
              </Tabs>
            </motion.aside>
          )}
        </AnimatePresence>

        <motion.main
          className="flex-1 bg-black relative"
          layout
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
        >
          {selectedChannel ? (
            <VideoPlayer
              channel={selectedChannel}
              volume={userPreferences.volume}
              onVolumeChange={(vol) => setUserPreferences((prev) => ({ ...prev, volume: vol }))}
              isFavorite={userPreferences.favorites.includes(selectedChannel.id)}
              onToggleFavorite={() => toggleFavorite(selectedChannel.id)}
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring" }}
                className="text-center p-8"
              >
                <Tv2 className="h-16 w-16 mx-auto mb-4 text-purple-500 opacity-50" />
                <p className="text-xl text-zinc-400">Select a channel to start watching</p>
                <Button variant="outline" className="mt-4" onClick={() => setSidebarOpen(true)}>
                  Browse Channels
                </Button>
              </motion.div>
            </div>
          )}

          {/* Mobile toggle for sidebar */}
          {!sidebarOpen && !isDesktop && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-4 left-4 p-2 bg-black/70 backdrop-blur-md rounded-full z-10"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </motion.button>
          )}
        </motion.main>

        <AnimatePresence>
          {isSettingsOpen && (
            <motion.div
              initial={{ x: 300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 300, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute top-0 right-0 bottom-0 w-full sm:w-80 bg-black/80 backdrop-blur-md border-l border-zinc-800/50 z-30 overflow-y-auto"
            >
              <div className="p-4 border-b border-zinc-800/50 flex justify-between items-center">
                <h2 className="text-lg font-semibold">Settings</h2>
                <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="p-4 space-y-6">
                <ThemeSelector
                  theme={userPreferences.theme}
                  onChange={(theme) => setUserPreferences((prev) => ({ ...prev, theme }))}
                />

                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-zinc-400">Playback Quality</h3>
                  <select
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-md p-2 text-sm"
                    value={userPreferences.quality}
                    onChange={(e) => setUserPreferences((prev) => ({ ...prev, quality: e.target.value }))}
                  >
                    <option value="auto">Auto (Recommended)</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-zinc-400">Experimental Features</h3>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        className="rounded border-zinc-700 text-purple-600 focus:ring-purple-600"
                        checked={userPreferences.enablePiP ?? false}
                        onChange={(e) => setUserPreferences((prev) => ({ ...prev, enablePiP: e.target.checked }))}
                      />
                      Picture-in-Picture
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        className="rounded border-zinc-700 text-purple-600 focus:ring-purple-600"
                        checked={userPreferences.enableAdvancedBuffering ?? true}
                        onChange={(e) =>
                          setUserPreferences((prev) => ({ ...prev, enableAdvancedBuffering: e.target.checked }))
                        }
                      />
                      Advanced Buffering
                    </label>
                  </div>
                </div>

                <div className="pt-4 border-t border-zinc-800/50">
                  <Button
                    variant="destructive"
                    className="w-full"
                    onClick={() => {
                      setUserPreferences(DEFAULT_PREFERENCES)
                      toast({
                        title: "Settings reset",
                        description: "All preferences have been reset to default",
                        duration: 3000,
                      })
                    }}
                  >
                    Reset All Settings
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
