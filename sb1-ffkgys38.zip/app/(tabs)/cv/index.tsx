import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Pressable } from 'react-native';
import { Stack } from 'expo-router';
import { Plus, Download, Share2, Eye } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

type Section = {
  id: string;
  type: 'experience' | 'education' | 'skills';
  title: string;
  subtitle?: string;
  description?: string;
  startDate?: string;
  endDate?: string;
};

export default function CVBuilder() {
  const [sections, setSections] = useState<Section[]>([]);
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [email, setEmail] = useState('');

  const addSection = (type: Section['type']) => {
    const newSection: Section = {
      id: Date.now().toString(),
      type,
      title: '',
    };
    setSections([...sections, newSection]);
  };

  const updateSection = (id: string, updates: Partial<Section>) => {
    setSections(sections.map(section => 
      section.id === id ? { ...section, ...updates } : section
    ));
  };

  return (
    <>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: 'CV Builder',
          headerShadowVisible: false,
          headerStyle: { backgroundColor: '#F9FAFB' },
        }}
      />
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <TextInput
            style={styles.nameInput}
            placeholder="Your Full Name"
            value={name}
            onChangeText={setName}
            placeholderTextColor="#6B7280"
          />
          <TextInput
            style={styles.titleInput}
            placeholder="Professional Title"
            value={title}
            onChangeText={setTitle}
            placeholderTextColor="#6B7280"
          />
          <TextInput
            style={styles.emailInput}
            placeholder="Email Address"
            value={email}
            onChangeText={setEmail}
            placeholderTextColor="#6B7280"
            keyboardType="email-address"
          />
        </View>

        <View style={styles.actions}>
          <Pressable style={styles.actionButton}>
            <Eye size={20} color="#4B5563" />
            <Text style={styles.actionText}>Preview</Text>
          </Pressable>
          <Pressable style={styles.actionButton}>
            <Download size={20} color="#4B5563" />
            <Text style={styles.actionText}>Export</Text>
          </Pressable>
          <Pressable style={styles.actionButton}>
            <Share2 size={20} color="#4B5563" />
            <Text style={styles.actionText}>Share</Text>
          </Pressable>
        </View>

        <View style={styles.sections}>
          {sections.map(section => (
            <View key={section.id} style={styles.section}>
              <TextInput
                style={styles.sectionTitle}
                placeholder="Section Title"
                value={section.title}
                onChangeText={(text) => updateSection(section.id, { title: text })}
                placeholderTextColor="#6B7280"
              />
              {(section.type === 'experience' || section.type === 'education') && (
                <>
                  <TextInput
                    style={styles.sectionSubtitle}
                    placeholder="Company / Institution"
                    value={section.subtitle}
                    onChangeText={(text) => updateSection(section.id, { subtitle: text })}
                    placeholderTextColor="#6B7280"
                  />
                  <View style={styles.dateContainer}>
                    <TextInput
                      style={styles.dateInput}
                      placeholder="Start Date"
                      value={section.startDate}
                      onChangeText={(text) => updateSection(section.id, { startDate: text })}
                      placeholderTextColor="#6B7280"
                    />
                    <Text style={styles.dateSeparator}>-</Text>
                    <TextInput
                      style={styles.dateInput}
                      placeholder="End Date"
                      value={section.endDate}
                      onChangeText={(text) => updateSection(section.id, { endDate: text })}
                      placeholderTextColor="#6B7280"
                    />
                  </View>
                </>
              )}
              <TextInput
                style={styles.sectionDescription}
                placeholder="Description"
                value={section.description}
                onChangeText={(text) => updateSection(section.id, { description: text })}
                placeholderTextColor="#6B7280"
                multiline
              />
            </View>
          ))}
        </View>

        <View style={styles.addSection}>
          <Text style={styles.addSectionTitle}>Add Section</Text>
          <View style={styles.addButtons}>
            <Pressable
              style={styles.addButton}
              onPress={() => addSection('experience')}>
              <LinearGradient
                colors={['#4F46E5', '#7C3AED']}
                style={styles.addButtonGradient}>
                <Plus size={24} color="white" />
              </LinearGradient>
              <Text style={styles.addButtonText}>Experience</Text>
            </Pressable>
            <Pressable
              style={styles.addButton}
              onPress={() => addSection('education')}>
              <LinearGradient
                colors={['#059669', '#10B981']}
                style={styles.addButtonGradient}>
                <Plus size={24} color="white" />
              </LinearGradient>
              <Text style={styles.addButtonText}>Education</Text>
            </Pressable>
            <Pressable
              style={styles.addButton}
              onPress={() => addSection('skills')}>
              <LinearGradient
                colors={['#DC2626', '#EF4444']}
                style={styles.addButtonGradient}>
                <Plus size={24} color="white" />
              </LinearGradient>
              <Text style={styles.addButtonText}>Skills</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  content: {
    padding: 16,
  },
  header: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  nameInput: {
    fontSize: 24,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  titleInput: {
    fontSize: 18,
    color: '#374151',
    marginBottom: 8,
  },
  emailInput: {
    fontSize: 16,
    color: '#4B5563',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  actionButton: {
    alignItems: 'center',
    padding: 8,
  },
  actionText: {
    marginTop: 4,
    fontSize: 12,
    color: '#4B5563',
  },
  sections: {
    gap: 16,
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 16,
    color: '#374151',
    marginBottom: 8,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  dateInput: {
    flex: 1,
    fontSize: 14,
    color: '#4B5563',
  },
  dateSeparator: {
    marginHorizontal: 8,
    color: '#6B7280',
  },
  sectionDescription: {
    fontSize: 14,
    color: '#4B5563',
    minHeight: 80,
    textAlignVertical: 'top',
  },
  addSection: {
    marginTop: 24,
    marginBottom: 32,
  },
  addSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
  },
  addButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  addButton: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 6,
  },
  addButtonGradient: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  addButtonText: {
    fontSize: 12,
    color: '#4B5563',
  },
});