"use client"

import { useEffect, useRef, useState, type RefObject } from "react"
import type { NetworkStats } from "@/lib/types"

interface HLSPlayerOptions {
  videoRef: RefObject<HTMLVideoElement>
  onError?: (message?: string) => void
  onLoading?: () => void
  onReady?: () => void
  onBuffering?: (isBuffering: boolean) => void
  onBufferingProgress?: (progress: number) => void
  enableAdvancedBuffering?: boolean
}

export function useHLSPlayer({
  videoRef,
  onError,
  onLoading,
  onReady,
  onBuffering,
  onBufferingProgress,
  enableAdvancedBuffering = true,
}: HLSPlayerOptions) {
  const hlsRef = useRef<any>(null)
  const [currentQuality, setCurrentQuality] = useState<string>("auto")
  const [networkStats, setNetworkStats] = useState<NetworkStats>({
    bitrate: 0,
    droppedFrames: 0,
    bufferHealth: 0,
  })

  // Initialize HLS.js
  const initHLS = async (streamUrl: string, quality = "auto") => {
    if (!videoRef.current) return

    try {
      onLoading?.()

      // Dynamically import HLS.js
      const Hls = (await import("hls.js")).default

      if (Hls.isSupported()) {
        // Clean up existing instance
        if (hlsRef.current) {
          hlsRef.current.destroy()
        }

        // Create new HLS instance
        const hls = new Hls({
          maxBufferLength: getBufferSize(),
          maxMaxBufferLength: getBufferSize() * 2,
          enableWorker: true,
          lowLatencyMode: false,
          startLevel: getQualityLevel(quality),
          capLevelToPlayerSize: true,
          debug: false,
        })

        hlsRef.current = hls

        // Bind HLS to video element
        hls.attachMedia(videoRef.current)

        // Load source
        hls.loadSource(streamUrl)

        // Setup event handlers
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (videoRef.current) {
            videoRef.current.play().catch((err) => {
              console.error("Play error:", err)
              onError?.("Failed to autoplay video. Please click play.")
            })
          }
          onReady?.()
        })

        hls.on(Hls.Events.ERROR, (_, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                // Try to recover network error
                console.log("Fatal network error encountered, trying to recover")
                hls.startLoad()
                break
              case Hls.ErrorTypes.MEDIA_ERROR:
                console.log("Fatal media error encountered, trying to recover")
                hls.recoverMediaError()
                break
              default:
                // Cannot recover
                hls.destroy()
                onError?.("Stream playback error: " + data.details)
                break
            }
          }
        })

        // Track buffering
        hls.on(Hls.Events.BUFFER_CREATED, () => {
          onBufferingProgress?.(10)
        })

        hls.on(Hls.Events.BUFFER_APPENDING, () => {
          onBufferingProgress?.(30)
        })

        hls.on(Hls.Events.BUFFER_APPENDED, () => {
          onBufferingProgress?.(60)
        })

        hls.on(Hls.Events.FRAG_BUFFERED, () => {
          onBufferingProgress?.(100)
        })

        // Track buffer state
        hls.on(Hls.Events.BUFFER_STALLED, () => {
          onBuffering?.(true)
        })

        hls.on(Hls.Events.BUFFER_FLUSHED, () => {
          onBuffering?.(false)
        })

        // Advanced buffering if enabled
        if (enableAdvancedBuffering) {
          setupAdvancedBuffering(hls)
        }

        setCurrentQuality(quality)
      } else if (videoRef.current.canPlayType("application/vnd.apple.mpegurl")) {
        // Fallback to native HLS support (Safari)
        videoRef.current.src = streamUrl
        videoRef.current.addEventListener("loadedmetadata", () => {
          videoRef.current?.play().catch((err) => {
            console.error("Play error:", err)
            onError?.("Failed to autoplay video. Please click play.")
          })
          onReady?.()
        })
        videoRef.current.addEventListener("error", () => {
          onError?.("Error loading video stream")
        })
      } else {
        onError?.("HLS playback is not supported in this browser")
      }
    } catch (error) {
      console.error("HLS init error:", error)
      onError?.("Failed to initialize video player")
    }
  }

  // Clean up HLS instance
  const destroyHLS = () => {
    if (hlsRef.current) {
      hlsRef.current.destroy()
      hlsRef.current = null
    }
  }

  // Change quality level
  const changeQuality = (quality: string) => {
    if (!hlsRef.current) return

    const level = getQualityLevel(quality)
    hlsRef.current.currentLevel = level
    setCurrentQuality(quality)
  }

  // Get current playback stats
  const getCurrentStats = (): NetworkStats => {
    if (!hlsRef.current || !videoRef.current) {
      return networkStats
    }

    try {
      const hls = hlsRef.current
      const stats = {
        bitrate: hls.bandwidthEstimate || 0,
        droppedFrames: videoRef.current.webkitDroppedFrameCount || 0,
        bufferHealth: videoRef.current.buffered.length
          ? videoRef.current.buffered.end(videoRef.current.buffered.length - 1) - videoRef.current.currentTime
          : 0,
      }

      setNetworkStats(stats)
      return stats
    } catch (error) {
      console.error("Error getting stats:", error)
      return networkStats
    }
  }

  // Helper to determine buffer size based on preferences
  const getBufferSize = () => {
    // This would normally come from user preferences
    const bufferSize = "default"

    switch (bufferSize) {
      case "small":
        return 30
      case "large":
        return 90
      case "xlarge":
        return 120
      case "default":
      default:
        return 60
    }
  }

  // Helper to determine quality level
  const getQualityLevel = (quality: string): number => {
    switch (quality) {
      case "low":
        return 0
      case "medium":
        return 1
      case "high":
        return 2
      case "auto":
      default:
        return -1 // Auto
    }
  }

  // Setup advanced buffering techniques
  const setupAdvancedBuffering = (hls: any) => {
    // Implement advanced buffering strategies

    // 1. Adaptive buffer size based on network conditions
    const adaptiveBufferController = () => {
      if (!navigator.onLine) return

      // Get connection type if available
      const connection = (navigator as any).connection

      if (connection) {
        const effectiveType = connection.effectiveType

        // Adjust buffer based on connection quality
        if (effectiveType === "4g") {
          hls.config.maxBufferLength = 30
        } else if (effectiveType === "3g") {
          hls.config.maxBufferLength = 60
        } else if (effectiveType === "2g" || effectiveType === "slow-2g") {
          hls.config.maxBufferLength = 90
        }
      }
    }

    // 2. Prefetch segments
    const prefetchSegments = (segmentUrls: string[]) => {
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "PREFETCH_SEGMENTS",
          urls: segmentUrls,
        })
      }
    }

    // Setup listeners for segment information
    hls.on(hls.Events.MANIFEST_PARSED, (_: any, data: any) => {
      adaptiveBufferController()
    })

    hls.on(hls.Events.LEVEL_LOADED, (_: any, data: any) => {
      if (data.details && data.details.fragments) {
        // Get URLs of next few segments for prefetching
        const segmentUrls = data.details.fragments
          .slice(0, 3)
          .map((fragment: any) => fragment.url)
          .filter(Boolean)

        if (segmentUrls.length) {
          prefetchSegments(segmentUrls)
        }
      }
    })

    // Listen for network changes
    if ("connection" in navigator) {
      ;(navigator as any).connection.addEventListener("change", adaptiveBufferController)
    }
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      destroyHLS()
    }
  }, [])

  return {
    initHLS,
    destroyHLS,
    changeQuality,
    getCurrentStats,
  }
}
