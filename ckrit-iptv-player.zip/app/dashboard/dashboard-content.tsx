"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BarChart,
  Calendar,
  Clock,
  Download,
  Heart,
  Home,
  ListMusic,
  LogOut,
  Settings,
  Tv,
  Upload,
  User,
} from "lucide-react"
import { signOut } from "@/app/actions"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"

interface DashboardContentProps {
  user: any
  settings: any
  watchHistory: any[]
  watchCount: number
  favorites: any[]
  playlists: any[]
}

export default function DashboardContent({
  user,
  settings,
  watchHistory,
  watchCount,
  favorites,
  playlists,
}: DashboardContentProps) {
  const [isLoggingOut, setIsLoggingOut] = useState(false)

  const handleLogout = async () => {
    setIsLoggingOut(true)
    await signOut()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-64 space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col items-center space-y-4 py-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={`https://avatar.vercel.sh/${user.email}`} />
                  <AvatarFallback>
                    {user.user_metadata?.full_name
                      ?.split(" ")
                      .map((n: string) => n[0])
                      .join("")
                      .toUpperCase() || user.email.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-1 text-center">
                  <h2 className="text-xl font-bold">{user.user_metadata?.full_name || "User"}</h2>
                  <p className="text-sm text-zinc-400">{user.email}</p>
                </div>
              </div>

              <div className="space-y-1 mt-4">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/">
                    <Home className="mr-2 h-4 w-4" />
                    Home
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard">
                    <BarChart className="mr-2 h-4 w-4" />
                    Dashboard
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/playlists">
                    <ListMusic className="mr-2 h-4 w-4" />
                    My Playlists
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/favorites">
                    <Heart className="mr-2 h-4 w-4" />
                    Favorites
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Link>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-red-500"
                  onClick={handleLogout}
                  disabled={isLoggingOut}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  {isLoggingOut ? "Logging out..." : "Log out"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <h1 className="text-3xl font-bold mb-6">Dashboard</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Watch History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{watchCount}</div>
                <p className="text-xs text-zinc-500">Channels watched</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Favorites</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{favorites.length}</div>
                <p className="text-xs text-zinc-500">Saved channels</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Playlists</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{playlists.length}</div>
                <p className="text-xs text-zinc-500">Custom playlists</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="activity">
            <TabsList className="mb-4">
              <TabsTrigger value="activity">Recent Activity</TabsTrigger>
              <TabsTrigger value="favorites">Favorites</TabsTrigger>
              <TabsTrigger value="playlists">Playlists</TabsTrigger>
            </TabsList>

            <TabsContent value="activity">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your recently watched channels</CardDescription>
                </CardHeader>
                <CardContent>
                  {watchHistory.length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="h-12 w-12 mx-auto text-zinc-700 mb-4" />
                      <p className="text-zinc-400">No watch history yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {watchHistory.map((item) => (
                        <div key={item.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-zinc-800/50">
                          <div className="w-10 h-10 bg-zinc-800 rounded overflow-hidden flex items-center justify-center">
                            <Tv className="h-5 w-5 text-zinc-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{item.channel_id}</p>
                            <p className="text-xs text-zinc-400">
                              {formatDistanceToNow(new Date(item.watched_at), { addSuffix: true })}
                            </p>
                          </div>
                          <Button variant="ghost" size="icon" asChild>
                            <Link href={`/channel/${item.channel_id}`}>
                              <Tv className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" asChild>
                    <Link href="/history">View all history</Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="favorites">
              <Card>
                <CardHeader>
                  <CardTitle>Favorite Channels</CardTitle>
                  <CardDescription>Your saved favorite channels</CardDescription>
                </CardHeader>
                <CardContent>
                  {favorites.length === 0 ? (
                    <div className="text-center py-8">
                      <Heart className="h-12 w-12 mx-auto text-zinc-700 mb-4" />
                      <p className="text-zinc-400">No favorites yet</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {favorites.map((channel) => (
                        <div key={channel.id} className="bg-zinc-800/50 rounded-lg p-4 flex items-center gap-3">
                          <div className="w-12 h-12 bg-zinc-700 rounded overflow-hidden flex items-center justify-center">
                            {channel.logo ? (
                              <img
                                src={channel.logo || "/placeholder.svg"}
                                alt={channel.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Tv className="h-6 w-6 text-zinc-400" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{channel.name}</p>
                            <p className="text-xs text-zinc-400">{channel.category || channel.country}</p>
                          </div>
                          <Button variant="ghost" size="icon" asChild>
                            <Link href={`/channel/${channel.id}`}>
                              <Tv className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" asChild>
                    <Link href="/favorites">View all favorites</Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="playlists">
              <Card>
                <CardHeader>
                  <CardTitle>Custom Playlists</CardTitle>
                  <CardDescription>Your created playlists</CardDescription>
                </CardHeader>
                <CardContent>
                  {playlists.length === 0 ? (
                    <div className="text-center py-8">
                      <ListMusic className="h-12 w-12 mx-auto text-zinc-700 mb-4" />
                      <p className="text-zinc-400">No playlists yet</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {playlists.map((playlist) => (
                        <div key={playlist.id} className="bg-zinc-800/50 rounded-lg p-4">
                          <div className="h-32 bg-zinc-700 rounded-lg mb-3 flex items-center justify-center">
                            {playlist.thumbnail_url ? (
                              <img
                                src={playlist.thumbnail_url || "/placeholder.svg"}
                                alt={playlist.name}
                                className="w-full h-full object-cover rounded-lg"
                              />
                            ) : (
                              <ListMusic className="h-12 w-12 text-zinc-500" />
                            )}
                          </div>
                          <h3 className="font-medium">{playlist.name}</h3>
                          {playlist.description && (
                            <p className="text-xs text-zinc-400 mt-1 line-clamp-2">{playlist.description}</p>
                          )}
                          <div className="flex justify-between items-center mt-3">
                            <p className="text-xs text-zinc-500">
                              {new Date(playlist.created_at).toLocaleDateString()}
                            </p>
                            <Button variant="ghost" size="sm" asChild>
                              <Link href={`/playlists/${playlist.id}`}>View</Link>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" asChild>
                    <Link href="/playlists">View all playlists</Link>
                  </Button>
                  <Button asChild>
                    <Link href="/playlists/create">
                      <ListMusic className="mr-2 h-4 w-4" />
                      Create Playlist
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Import/Export</CardTitle>
                <CardDescription>Manage your data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Import M3U Playlist</p>
                    <p className="text-xs text-zinc-400">Add channels from an M3U file</p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Upload className="mr-2 h-4 w-4" />
                    Import
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Export Favorites</p>
                    <p className="text-xs text-zinc-400">Download your favorites as M3U</p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Export Playlists</p>
                    <p className="text-xs text-zinc-400">Download your playlists as M3U</p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Profile</p>
                    <p className="text-xs text-zinc-400">Update your personal information</p>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/settings/profile">
                      <User className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Preferences</p>
                    <p className="text-xs text-zinc-400">Customize your experience</p>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/settings/preferences">
                      <Settings className="mr-2 h-4 w-4" />
                      Edit
                    </Link>
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Subscription</p>
                    <p className="text-xs text-zinc-400">Manage your subscription</p>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/settings/subscription">
                      <Calendar className="mr-2 h-4 w-4" />
                      Manage
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
