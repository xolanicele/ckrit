import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DashboardContent from "./dashboard-content"

export default async function DashboardPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If not logged in, redirect to login page
  if (!session) {
    redirect("/auth/login")
  }

  // Get user data
  const { data: userData } = await supabase.from("user_settings").select("*").eq("user_id", session.user.id).single()

  // Get watch history stats
  const { data: watchHistory, count: watchCount } = await supabase
    .from("watch_history")
    .select("*", { count: "exact" })
    .eq("user_id", session.user.id)
    .order("watched_at", { ascending: false })
    .limit(10)

  // Get favorite channels
  const { data: favorites } = await supabase
    .from("user_favorites")
    .select(`
      channels (
        id,
        name,
        logo,
        category,
        country
      )
    `)
    .eq("user_id", session.user.id)
    .limit(10)

  // Get custom playlists
  const { data: playlists } = await supabase.from("custom_playlists").select("*").eq("user_id", session.user.id)

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black text-white">
      <DashboardContent
        user={session.user}
        settings={userData}
        watchHistory={watchHistory || []}
        watchCount={watchCount || 0}
        favorites={favorites?.map((f) => f.channels) || []}
        playlists={playlists || []}
      />
    </div>
  )
}
