import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import AuthForm from "@/components/auth/auth-form"
import { Tv2 } from "lucide-react"

export default async function LoginPage() {
  try {
    const supabase = createClient()
    const { data } = await supabase.auth.getSession()

    // If user is already logged in, redirect to home
    if (data?.session) {
      redirect("/")
    }

    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-zinc-900 to-black">
        <div className="w-full max-w-md p-8 space-y-8 bg-zinc-900/50 backdrop-blur-md rounded-lg border border-zinc-800/50">
          <div className="text-center">
            <div className="flex justify-center">
              <Tv2 className="h-12 w-12 text-purple-500" />
            </div>
            <h1 className="mt-4 text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
              Mjeyi&apos;s IPTV Services
            </h1>
            <p className="mt-2 text-zinc-400">Sign in to access your personalized IPTV experience</p>
          </div>

          <AuthForm />
        </div>
      </div>
    )
  } catch (error) {
    console.error("Error initializing Supabase client:", error)

    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-zinc-900 to-black">
        <div className="w-full max-w-md p-8 space-y-8 bg-zinc-900/50 backdrop-blur-md rounded-lg border border-zinc-800/50">
          <div className="text-center">
            <div className="flex justify-center">
              <Tv2 className="h-12 w-12 text-purple-500" />
            </div>
            <h1 className="mt-4 text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
              Mjeyi&apos;s IPTV Services
            </h1>
            <p className="mt-2 text-zinc-400">Connection Error: Unable to connect to the authentication service</p>
            <p className="mt-2 text-sm text-zinc-500">
              Please make sure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY are properly configured.
            </p>
          </div>
        </div>
      </div>
    )
  }
}
