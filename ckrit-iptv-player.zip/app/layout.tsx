import type React from "react"
import type { Metadata } from "next"
import ClientLayout from "./ClientLayout"

export const metadata: Metadata = {
  title: "Mjeyi's IPTV Services",
  description: "Premium IPTV experience with advanced features and smooth playback",
  keywords: "iptv, streaming, live tv, channels, mjeyi",
  authors: [{ name: "Mjeyi" }],
  viewport: "width=device-width, initial-scale=1",
  themeColor: "#8B5CF6",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <ClientLayout>{children}</ClientLayout>
}


import './globals.css'