"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { signIn } from "@/lib/auth"
import * as db from "@/lib/db"
import * as redis from "@/lib/redis"
import { fetchChannels } from "@/lib/iptv-service"
import { createClient } from "@/lib/supabase/server"
import { fetchChannels as fetchChannelsFromAPI } from "@/lib/iptv-service"

// Auth actions
export async function login(formData: FormData) {
  const email = formData.get("email") as string
  const name = formData.get("name") as string

  if (!email || !name) {
    return { error: "Email and name are required" }
  }

  try {
    await signIn(email, name)
    revalidatePath("/")
    redirect("/")
  } catch (error) {
    console.error("Login error:", error)
    return { error: "Failed to sign in" }
  }
}

// Sign out
export async function signOut() {
  const supabase = createClient()
  await supabase.auth.signOut()
  revalidatePath("/")
  redirect("/auth/login")
}

// Alias for signOut for backward compatibility
export async function logout() {
  return signOut()
}

// Get current user
export async function getCurrentUser() {
  const supabase = createClient()
  const { data, error } = await supabase.auth.getUser()

  if (error || !data?.user) {
    return null
  }

  return data.user
}

// Channel actions
export async function getChannelsFromDb() {
  // Try to get from Redis cache first
  const cachedChannels = await redis.getCachedChannels()
  if (cachedChannels) {
    return cachedChannels
  }

  // If not in cache, get from database
  const channels = await db.getChannels()

  // If database is empty, fetch from API and save to database
  if (channels.length === 0) {
    const apiChannels = await fetchChannels()

    // Save channels to database
    for (const channel of apiChannels) {
      await db.saveChannel({
        id: channel.id,
        name: channel.name,
        url: channel.url,
        logo: channel.logo,
        category: channel.category,
        country: channel.country,
        language: channel.language || "",
        isActive: channel.isActive,
      })
    }

    // Get channels from database again
    const freshChannels = await db.getChannels()

    // Cache the channels
    await redis.cacheChannels(freshChannels)

    return freshChannels
  }

  // Cache the channels
  await redis.cacheChannels(channels)

  return channels
}

// Channel operations
export async function getChannels() {
  const supabase = createClient()

  // Try to get channels from database
  const { data: channels, error } = await supabase.from("channels").select("*").order("name")

  if (error) {
    console.error("Error fetching channels:", error)
    return []
  }

  // If no channels in database, fetch from API and save
  if (channels.length === 0) {
    const apiChannels = await fetchChannelsFromAPI()

    // Save channels to database
    for (const channel of apiChannels) {
      await supabase.from("channels").insert({
        id: channel.id,
        name: channel.name,
        url: channel.url,
        logo: channel.logo,
        category: channel.category,
        country: channel.country,
        language: channel.language || null,
        is_active: channel.isActive,
      })
    }

    // Get channels from database again
    const { data: freshChannels } = await supabase.from("channels").select("*").order("name")

    return freshChannels || []
  }

  return channels
}

export async function refreshChannels() {
  // Fetch fresh channels from API
  const apiChannels = await fetchChannels()

  // Update database
  for (const channel of apiChannels) {
    await db.saveChannel({
      id: channel.id,
      name: channel.name,
      url: channel.url,
      logo: channel.logo,
      category: channel.category,
      country: channel.country,
      language: channel.language || "",
      isActive: channel.isActive,
    })
  }

  // Invalidate cache
  await redis.invalidateChannelsCache()

  revalidatePath("/")
  return { success: true }
}

// Get alternative streams for a channel
export async function getAlternativeStreams(channelId: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("alternative_streams")
    .select("*")
    .eq("channel_id", channelId)
    .eq("is_active", true)
    .order("votes", { ascending: false })

  if (error) {
    console.error("Error fetching alternative streams:", error)
    return []
  }

  return data
}

// Add alternative stream
export async function addAlternativeStream(channelId: string, url: string, quality?: string, source?: string) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to add streams" }
  }

  const { data, error } = await supabase
    .from("alternative_streams")
    .insert({
      channel_id: channelId,
      url,
      quality,
      source,
      user_submitted: true,
      user_id: user.id,
    })
    .select()

  if (error) {
    console.error("Error adding alternative stream:", error)
    return { error: error.message }
  }

  revalidatePath(`/channel/${channelId}`)
  return { success: true, stream: data[0] }
}

// Vote for alternative stream
export async function voteForStream(streamId: number) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to vote" }
  }

  // Get current stream to get channel_id for revalidation
  const { data: stream } = await supabase.from("alternative_streams").select("channel_id").eq("id", streamId).single()

  // Increment votes
  const { error } = await supabase.rpc("increment_stream_votes", { stream_id: streamId })

  if (error) {
    console.error("Error voting for stream:", error)
    return { error: error.message }
  }

  if (stream) {
    revalidatePath(`/channel/${stream.channel_id}`)
  }

  return { success: true }
}

// Favorites actions
export async function getUserFavorites() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return []
  }

  const { data, error } = await supabase.from("user_favorites").select("channel_id").eq("user_id", user.id)

  if (error) {
    console.error("Error fetching favorites:", error)
    return []
  }

  return data.map((fav) => fav.channel_id)
}

// Toggle favorite
export async function toggleFavorite(channelId: string) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to manage favorites" }
  }

  // Check if already a favorite
  const { data: existing } = await supabase
    .from("user_favorites")
    .select("id")
    .eq("user_id", user.id)
    .eq("channel_id", channelId)
    .maybeSingle()

  if (existing) {
    // Remove from favorites
    const { error } = await supabase.from("user_favorites").delete().eq("id", existing.id)

    if (error) {
      console.error("Error removing favorite:", error)
      return { error: error.message }
    }
  } else {
    // Add to favorites
    const { error } = await supabase.from("user_favorites").insert({ user_id: user.id, channel_id: channelId })

    if (error) {
      console.error("Error adding favorite:", error)
      return { error: error.message }
    }
  }

  revalidatePath("/")
  return { success: true }
}

// Watch history actions
export async function addToWatchHistory(channelId: string, duration = 0, position = 0) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to track history" }
  }

  const { error } = await supabase.from("watch_history").insert({
    user_id: user.id,
    channel_id: channelId,
    duration,
    position,
  })

  if (error) {
    console.error("Error adding to watch history:", error)
    return { error: error.message }
  }

  // Update user settings with last channel
  await supabase.from("user_settings").upsert({
    user_id: user.id,
    last_channel: channelId,
  })

  return { success: true }
}

// Get watch history
export async function getWatchHistory() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return []
  }

  const { data, error } = await supabase
    .from("watch_history")
    .select(`
      id,
      channel_id,
      watched_at,
      duration,
      position,
      channels (
        name,
        logo,
        category
      )
    `)
    .eq("user_id", user.id)
    .order("watched_at", { ascending: false })
    .limit(50)

  if (error) {
    console.error("Error fetching watch history:", error)
    return []
  }

  return data
}

// Get watch history
export async function getUserWatchHistory() {
  // This function is an alias for getWatchHistory for backward compatibility
  return getWatchHistory()
}

// Clear watch history
export async function clearWatchHistory() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to clear history" }
  }

  const { error } = await supabase.from("watch_history").delete().eq("user_id", user.id)

  if (error) {
    console.error("Error clearing watch history:", error)
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}

// User settings actions
export async function getUserSettings() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return null
  }

  const { data, error } = await supabase.from("user_settings").select("*").eq("user_id", user.id).maybeSingle()

  if (error) {
    console.error("Error fetching user settings:", error)
    return null
  }

  return data
}

// Save user settings
export async function saveUserSettings(settings: any) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to save settings" }
  }

  const { error } = await supabase.from("user_settings").upsert({
    user_id: user.id,
    ...settings,
  })

  if (error) {
    console.error("Error saving user settings:", error)
    return { error: error.message }
  }

  revalidatePath("/")
  return { success: true }
}

// Custom playlists actions
export async function getUserPlaylists() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return []
  }

  const { data, error } = await supabase
    .from("custom_playlists")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching playlists:", error)
    return []
  }

  return data
}

// Create playlist
export async function createPlaylist(name: string, description?: string, isPublic = false) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to create playlists" }
  }

  const { data, error } = await supabase
    .from("custom_playlists")
    .insert({
      user_id: user.id,
      name,
      description,
      is_public: isPublic,
    })
    .select()

  if (error) {
    console.error("Error creating playlist:", error)
    return { error: error.message }
  }

  revalidatePath("/playlists")
  return { success: true, playlist: data[0] }
}

// Get playlist channels
export async function getPlaylistChannels(playlistId: number) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("playlist_channels")
    .select(`
      id,
      position,
      channels (*)
    `)
    .eq("playlist_id", playlistId)
    .order("position")

  if (error) {
    console.error("Error fetching playlist channels:", error)
    return []
  }

  return data
}

// Add channel to playlist
export async function addChannelToPlaylist(playlistId: number, channelId: string) {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to modify playlists" }
  }

  // Check if user owns the playlist
  const { data: playlist } = await supabase
    .from("custom_playlists")
    .select("id")
    .eq("id", playlistId)
    .eq("user_id", user.id)
    .maybeSingle()

  if (!playlist) {
    return { error: "You don't have permission to modify this playlist" }
  }

  // Get current highest position
  const { data: positions } = await supabase
    .from("playlist_channels")
    .select("position")
    .eq("playlist_id", playlistId)
    .order("position", { ascending: false })
    .limit(1)

  const position = positions && positions.length > 0 ? positions[0].position + 1 : 0

  // Add channel to playlist
  const { error } = await supabase.from("playlist_channels").insert({
    playlist_id: playlistId,
    channel_id: channelId,
    position,
  })

  if (error) {
    console.error("Error adding channel to playlist:", error)
    return { error: error.message }
  }

  revalidatePath(`/playlists/${playlistId}`)
  return { success: true }
}

// EPG functions
export async function getEPGForChannel(channelId: string) {
  const supabase = createClient()
  const now = new Date().toISOString()

  const { data, error } = await supabase
    .from("epg_programs")
    .select("*")
    .eq("channel_id", channelId)
    .gte("end_time", now)
    .order("start_time")
    .limit(24)

  if (error) {
    console.error("Error fetching EPG data:", error)
    return []
  }

  return data
}

// Get current program for a channel
export async function getCurrentProgram(channelId: string) {
  const supabase = createClient()
  const now = new Date().toISOString()

  const { data, error } = await supabase
    .from("epg_programs")
    .select("*")
    .eq("channel_id", channelId)
    .lte("start_time", now)
    .gte("end_time", now)
    .maybeSingle()

  if (error) {
    console.error("Error fetching current program:", error)
    return null
  }

  return data
}

// Search functions
export async function searchChannels(query: string) {
  const supabase = createClient()
  const user = await getCurrentUser()

  // Save search query to history if user is logged in
  if (user) {
    await supabase.from("search_history").insert({
      user_id: user.id,
      query,
    })
  }

  // Search channels
  const { data, error } = await supabase
    .from("channels")
    .select("*")
    .or(`name.ilike.%${query}%,category.ilike.%${query}%,country.ilike.%${query}%`)
    .order("name")
    .limit(50)

  if (error) {
    console.error("Error searching channels:", error)
    return []
  }

  return data
}

// Get search history
export async function getSearchHistory() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return []
  }

  const { data, error } = await supabase
    .from("search_history")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(10)

  if (error) {
    console.error("Error fetching search history:", error)
    return []
  }

  return data
}

// Clear search history
export async function clearSearchHistory() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    return { error: "You must be logged in to clear search history" }
  }

  const { error } = await supabase.from("search_history").delete().eq("user_id", user.id)

  if (error) {
    console.error("Error clearing search history:", error)
    return { error: error.message }
  }

  revalidatePath("/search")
  return { success: true }
}

// Recommendations
export async function getRecommendedChannels() {
  const supabase = createClient()
  const user = await getCurrentUser()

  if (!user) {
    // Return popular channels for non-logged in users
    const { data } = await supabase.from("channels").select("*").order("name").limit(10)

    return data || []
  }

  // Get user's recommendations
  const { data: recommendations } = await supabase
    .from("user_recommendations")
    .select(`
      channel_id,
      score,
      channels (*)
    `)
    .eq("user_id", user.id)
    .order("score", { ascending: false })
    .limit(20)

  if (recommendations && recommendations.length > 0) {
    return recommendations.map((rec) => rec.channels)
  }

  // If no recommendations, generate some based on watch history
  const { data: history } = await supabase
    .from("watch_history")
    .select("channel_id, channels (category)")
    .eq("user_id", user.id)
    .order("watched_at", { ascending: false })
    .limit(5)

  if (history && history.length > 0) {
    // Get categories from recent watch history
    const categories = history.map((h) => h.channels?.category).filter(Boolean) as string[]

    // Find channels in those categories
    if (categories.length > 0) {
      const { data: similarChannels } = await supabase
        .from("channels")
        .select("*")
        .in("category", categories)
        .not(
          "id",
          "in",
          history.map((h) => h.channel_id),
        )
        .limit(10)

      return similarChannels || []
    }
  }

  // Fallback to popular channels
  const { data: popularChannels } = await supabase.from("channels").select("*").order("name").limit(10)

  return popularChannels || []
}
