import { Suspense } from "react"
import LoadingScreen from "@/components/loading-screen"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import IPTVPlayer from "@/components/iptv-player"

export default async function Home() {
  try {
    const supabase = createClient()
    const {
      data: { session },
    } = await supabase.auth.getSession()

    // If not logged in, redirect to login page
    if (!session) {
      redirect("/auth/login")
    }

    return (
      <main className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black text-white">
        <Suspense fallback={<LoadingScreen />}>
          <IPTVPlayer />
        </Suspense>
      </main>
    )
  } catch (error) {
    console.error("Error initializing Supabase client:", error)

    // Show a more user-friendly error message
    return (
      <main className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black text-white flex items-center justify-center">
        <div className="text-center p-8 max-w-md">
          <h1 className="text-3xl font-bold mb-4">Connection Error</h1>
          <p className="mb-4">Unable to connect to the authentication service. Please try again later.</p>
          <p className="text-sm text-zinc-400">
            Make sure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY are properly configured.
          </p>
        </div>
      </main>
    )
  }
}
