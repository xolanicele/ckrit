import LoginForm from "./login-form"
import { getUser } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function LoginPage() {
  // If user is already logged in, redirect to home
  const user = await getUser()
  if (user) {
    redirect("/")
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-zinc-900 to-black">
      <div className="w-full max-w-md p-8 space-y-8 bg-zinc-900/50 backdrop-blur-md rounded-lg border border-zinc-800/50">
        <div className="text-center">
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
            Mjeyi&apos;s IPTV Services
          </h1>
          <p className="mt-2 text-zinc-400">Sign in to access your personalized IPTV experience</p>
        </div>

        <LoginForm />
      </div>
    </div>
  )
}
