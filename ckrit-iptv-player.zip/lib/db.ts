import { neon } from "@neondatabase/serverless"
import { drizzle } from "drizzle-orm/neon-http"
import { eq } from "drizzle-orm"
import * as schema from "./schema"

// Initialize Neon client
const sql = neon(process.env.DATABASE_URL!)
export const db = drizzle(sql, { schema })

// User functions
export async function getUserById(id: number) {
  const users = await db.select().from(schema.users).where(eq(schema.users.id, id))
  return users[0] || null
}

export async function getUserByEmail(email: string) {
  const users = await db.select().from(schema.users).where(eq(schema.users.email, email))
  return users[0] || null
}

export async function createUser(email: string, name: string) {
  const result = await db.insert(schema.users).values({ email, name }).returning()
  return result[0]
}

// Channel functions
export async function getChannels() {
  return db.select().from(schema.channels)
}

export async function getChannelById(id: string) {
  const channels = await db.select().from(schema.channels).where(eq(schema.channels.id, id))
  return channels[0] || null
}

export async function saveChannel(channel: schema.InsertChannel) {
  // Check if channel exists
  const existing = await getChannelById(channel.id)

  if (existing) {
    // Update existing channel
    return db
      .update(schema.channels)
      .set({
        name: channel.name,
        url: channel.url,
        logo: channel.logo,
        category: channel.category,
        country: channel.country,
        language: channel.language,
        isActive: channel.isActive,
        lastChecked: new Date(),
      })
      .where(eq(schema.channels.id, channel.id))
      .returning()
  } else {
    // Insert new channel
    return db.insert(schema.channels).values(channel).returning()
  }
}

// Other database functions can be added here as needed
