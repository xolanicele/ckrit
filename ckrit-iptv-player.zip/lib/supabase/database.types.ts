export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      channels: {
        Row: {
          id: string
          name: string
          url: string
          logo: string | null
          category: string | null
          country: string | null
          language: string | null
          is_active: boolean
          last_checked: string
          stream_quality: string | null
          has_timeshift: boolean
          timeshift_url: string | null
          epg_id: string | null
        }
        Insert: {
          id: string
          name: string
          url: string
          logo?: string | null
          category?: string | null
          country?: string | null
          language?: string | null
          is_active?: boolean
          last_checked?: string
          stream_quality?: string | null
          has_timeshift?: boolean
          timeshift_url?: string | null
          epg_id?: string | null
        }
        Update: {
          id?: string
          name?: string
          url?: string
          logo?: string | null
          category?: string | null
          country?: string | null
          language?: string | null
          is_active?: boolean
          last_checked?: string
          stream_quality?: string | null
          has_timeshift?: boolean
          timeshift_url?: string | null
          epg_id?: string | null
        }
      }
      user_favorites: {
        Row: {
          id: number
          user_id: string
          channel_id: string
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          channel_id: string
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          channel_id?: string
          created_at?: string
        }
      }
      watch_history: {
        Row: {
          id: number
          user_id: string
          channel_id: string
          watched_at: string
          duration: number
          position: number
        }
        Insert: {
          id?: number
          user_id: string
          channel_id: string
          watched_at?: string
          duration?: number
          position?: number
        }
        Update: {
          id?: number
          user_id?: string
          channel_id?: string
          watched_at?: string
          duration?: number
          position?: number
        }
      }
      user_settings: {
        Row: {
          user_id: string
          theme: string
          volume: number
          quality: string
          enable_pip: boolean
          enable_advanced_buffering: boolean
          last_channel: string | null
          auto_start_playback: boolean
          preferred_categories: string[] | null
          preferred_languages: string[] | null
          enable_timeshift: boolean
          enable_recommendations: boolean
          buffer_size: string
          subtitle_language: string
          subtitle_size: string
        }
        Insert: {
          user_id: string
          theme?: string
          volume?: number
          quality?: string
          enable_pip?: boolean
          enable_advanced_buffering?: boolean
          last_channel?: string | null
          auto_start_playback?: boolean
          preferred_categories?: string[] | null
          preferred_languages?: string[] | null
          enable_timeshift?: boolean
          enable_recommendations?: boolean
          buffer_size?: string
          subtitle_language?: string
          subtitle_size?: string
        }
        Update: {
          user_id?: string
          theme?: string
          volume?: number
          quality?: string
          enable_pip?: boolean
          enable_advanced_buffering?: boolean
          last_channel?: string | null
          auto_start_playback?: boolean
          preferred_categories?: string[] | null
          preferred_languages?: string[] | null
          enable_timeshift?: boolean
          enable_recommendations?: boolean
          buffer_size?: string
          subtitle_language?: string
          subtitle_size?: string
        }
      }
      custom_playlists: {
        Row: {
          id: number
          user_id: string
          name: string
          description: string | null
          is_public: boolean
          thumbnail_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: string
          name: string
          description?: string | null
          is_public?: boolean
          thumbnail_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          name?: string
          description?: string | null
          is_public?: boolean
          thumbnail_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      playlist_channels: {
        Row: {
          id: number
          playlist_id: number
          channel_id: string
          position: number
        }
        Insert: {
          id?: number
          playlist_id: number
          channel_id: string
          position: number
        }
        Update: {
          id?: number
          playlist_id?: number
          channel_id?: string
          position?: number
        }
      }
      epg_programs: {
        Row: {
          id: number
          channel_id: string
          title: string
          description: string | null
          start_time: string
          end_time: string
          category: string | null
          image_url: string | null
          created_at: string
        }
        Insert: {
          id?: number
          channel_id: string
          title: string
          description?: string | null
          start_time: string
          end_time: string
          category?: string | null
          image_url?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          channel_id?: string
          title?: string
          description?: string | null
          start_time?: string
          end_time?: string
          category?: string | null
          image_url?: string | null
          created_at?: string
        }
      }
      alternative_streams: {
        Row: {
          id: number
          channel_id: string
          url: string
          quality: string | null
          source: string | null
          is_active: boolean
          last_checked: string
          user_submitted: boolean
          user_id: string | null
          votes: number
        }
        Insert: {
          id?: number
          channel_id: string
          url: string
          quality?: string | null
          source?: string | null
          is_active?: boolean
          last_checked?: string
          user_submitted?: boolean
          user_id?: string | null
          votes?: number
        }
        Update: {
          id?: number
          channel_id?: string
          url?: string
          quality?: string | null
          source?: string | null
          is_active?: boolean
          last_checked?: string
          user_submitted?: boolean
          user_id?: string | null
          votes?: number
        }
      }
      channel_categories: {
        Row: {
          id: number
          name: string
          icon: string | null
          color: string | null
          position: number
        }
        Insert: {
          id?: number
          name: string
          icon?: string | null
          color?: string | null
          position?: number
        }
        Update: {
          id?: number
          name?: string
          icon?: string | null
          color?: string | null
          position?: number
        }
      }
      search_history: {
        Row: {
          id: number
          user_id: string
          query: string
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          query: string
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          query?: string
          created_at?: string
        }
      }
      user_recommendations: {
        Row: {
          id: number
          user_id: string
          channel_id: string
          score: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: number
          user_id: string
          channel_id: string
          score?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          channel_id?: string
          score?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
