import { kv } from "@vercel/kv"

// Cache keys
const CHANNELS_CACHE_KEY = "channels"
const CHANNEL_STATUS_PREFIX = "channel_status:"
const ACTIVE_VIEWERS_PREFIX = "active_viewers:"
const STREAM_HEALTH_PREFIX = "stream_health:"
const EPG_CACHE_PREFIX = "epg:"
const SEARCH_CACHE_PREFIX = "search:"
const RECOMMENDATIONS_PREFIX = "recommendations:"

// Cache durations
const CHANNELS_CACHE_TTL = 60 * 60 // 1 hour
const CHANNEL_STATUS_TTL = 60 * 5 // 5 minutes
const ACTIVE_VIEWERS_TTL = 60 // 1 minute
const STREAM_HEALTH_TTL = 60 * 10 // 10 minutes
const EPG_CACHE_TTL = 60 * 30 // 30 minutes
const SEARCH_CACHE_TTL = 60 * 5 // 5 minutes
const RECOMMENDATIONS_TTL = 60 * 60 * 24 // 24 hours

// Channel caching
export async function cacheChannels(channels: any[]) {
  await kv.set(CHANNELS_CACHE_KEY, JSON.stringify(channels), { ex: CHANNELS_CACHE_TTL })
  return channels
}

export async function getCachedChannels() {
  const cached = await kv.get<string>(CHANNELS_CACHE_KEY)
  return cached ? JSON.parse(cached) : null
}

export async function invalidateChannelsCache() {
  await kv.del(CHANNELS_CACHE_KEY)
}

// Channel status caching
export async function cacheChannelStatus(channelId: string, isActive: boolean) {
  await kv.set(`${CHANNEL_STATUS_PREFIX}${channelId}`, isActive, { ex: CHANNEL_STATUS_TTL })
  return isActive
}

export async function getCachedChannelStatus(channelId: string) {
  return await kv.get<boolean>(`${CHANNEL_STATUS_PREFIX}${channelId}`)
}

// Active viewers tracking
export async function trackChannelView(channelId: string) {
  const viewerId = crypto.randomUUID()
  const key = `${ACTIVE_VIEWERS_PREFIX}${channelId}`

  await kv.sadd(key, viewerId)
  await kv.expire(key, ACTIVE_VIEWERS_TTL)

  return viewerId
}

export async function removeChannelViewer(channelId: string, viewerId: string) {
  await kv.srem(`${ACTIVE_VIEWERS_PREFIX}${channelId}`, viewerId)
}

export async function getChannelViewerCount(channelId: string) {
  return await kv.scard(`${ACTIVE_VIEWERS_PREFIX}${channelId}`)
}

// Stream health monitoring
export async function updateStreamHealth(
  channelId: string,
  metrics: {
    bitrate?: number
    bufferHealth?: number
    droppedFrames?: number
    errors?: number
  },
) {
  const key = `${STREAM_HEALTH_PREFIX}${channelId}`
  await kv.hset(key, metrics)
  await kv.expire(key, STREAM_HEALTH_TTL)
}

export async function getStreamHealth(channelId: string) {
  const key = `${STREAM_HEALTH_PREFIX}${channelId}`
  return await kv.hgetall(key)
}

// EPG caching
export async function cacheEPGData(channelId: string, programs: any[]) {
  const key = `${EPG_CACHE_PREFIX}${channelId}`
  await kv.set(key, JSON.stringify(programs), { ex: EPG_CACHE_TTL })
}

export async function getCachedEPGData(channelId: string) {
  const key = `${EPG_CACHE_PREFIX}${channelId}`
  const cached = await kv.get<string>(key)
  return cached ? JSON.parse(cached) : null
}

// Search caching
export async function cacheSearchResults(query: string, results: any[]) {
  const key = `${SEARCH_CACHE_PREFIX}${query.toLowerCase()}`
  await kv.set(key, JSON.stringify(results), { ex: SEARCH_CACHE_TTL })
}

export async function getCachedSearchResults(query: string) {
  const key = `${SEARCH_CACHE_PREFIX}${query.toLowerCase()}`
  const cached = await kv.get<string>(key)
  return cached ? JSON.parse(cached) : null
}

// Recommendations
export async function cacheUserRecommendations(userId: string, recommendations: any[]) {
  const key = `${RECOMMENDATIONS_PREFIX}${userId}`
  await kv.set(key, JSON.stringify(recommendations), { ex: RECOMMENDATIONS_TTL })
}

export async function getCachedUserRecommendations(userId: string) {
  const key = `${RECOMMENDATIONS_PREFIX}${userId}`
  const cached = await kv.get<string>(key)
  return cached ? JSON.parse(cached) : null
}

// Rate limiting
export async function checkRateLimit(key: string, limit: number, windowSec: number) {
  const current = await kv.incr(key)
  if (current === 1) {
    await kv.expire(key, windowSec)
  }
  return current <= limit
}

// Stream finder - track unofficial streams
export async function trackUnofficialStream(channelName: string, url: string, source: string) {
  const key = `unofficial_streams:${channelName.toLowerCase()}`
  await kv.sadd(key, JSON.stringify({ url, source, timestamp: Date.now() }))
}

export async function getUnofficialStreams(channelName: string) {
  const key = `unofficial_streams:${channelName.toLowerCase()}`
  const streams = await kv.smembers(key)
  return streams.map((stream) => JSON.parse(stream as string))
}

// Analytics
export async function incrementChannelView(channelId: string) {
  const key = `analytics:channel_views:${channelId}`
  const date = new Date().toISOString().split("T")[0] // YYYY-MM-DD
  await kv.hincrby(key, date, 1)
}

export async function getChannelViewStats(channelId: string, days = 7) {
  const key = `analytics:channel_views:${channelId}`
  const stats = await kv.hgetall(key)

  // Filter to last N days
  const result: Record<string, number> = {}
  const dates = Object.keys(stats || {})
    .sort()
    .slice(-days)

  for (const date of dates) {
    result[date] = Number(stats?.[date] || 0)
  }

  return result
}
