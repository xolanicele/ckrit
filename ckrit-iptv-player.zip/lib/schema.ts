import { pgTable, serial, varchar, text, timestamp, boolean, integer, decimal, unique } from "drizzle-orm/pg-core"
import type { InferInsertModel, InferSelectModel } from "drizzle-orm"

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  name: varchar("name", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
})

// Channels table
export const channels = pgTable("channels", {
  id: varchar("id", { length: 255 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  url: text("url").notNull(),
  logo: text("logo"),
  category: varchar("category", { length: 255 }),
  country: varchar("country", { length: 255 }),
  language: varchar("language", { length: 255 }),
  isActive: boolean("is_active").default(true),
  lastChecked: timestamp("last_checked").defaultNow(),
})

// User favorites table
export const userFavorites = pgTable(
  "user_favorites",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    channelId: varchar("channel_id", { length: 255 })
      .references(() => channels.id, { onDelete: "cascade" })
      .notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => {
    return {
      unq: unique().on(table.userId, table.channelId),
    }
  },
)

// Watch history table
export const watchHistory = pgTable("watch_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  channelId: varchar("channel_id", { length: 255 })
    .references(() => channels.id, { onDelete: "cascade" })
    .notNull(),
  watchedAt: timestamp("watched_at").defaultNow(),
})

// User settings table
export const userSettings = pgTable("user_settings", {
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .primaryKey(),
  theme: varchar("theme", { length: 50 }).default("dark"),
  volume: decimal("volume", { precision: 4, scale: 3 }).default("0.8"),
  quality: varchar("quality", { length: 50 }).default("auto"),
  enablePip: boolean("enable_pip").default(true),
  enableAdvancedBuffering: boolean("enable_advanced_buffering").default(true),
  lastChannel: varchar("last_channel", { length: 255 }).references(() => channels.id, { onDelete: "set null" }),
})

// Custom playlists table
export const customPlaylists = pgTable("custom_playlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
})

// Playlist channels table
export const playlistChannels = pgTable(
  "playlist_channels",
  {
    id: serial("id").primaryKey(),
    playlistId: integer("playlist_id")
      .references(() => customPlaylists.id, { onDelete: "cascade" })
      .notNull(),
    channelId: varchar("channel_id", { length: 255 })
      .references(() => channels.id, { onDelete: "cascade" })
      .notNull(),
    position: integer("position").notNull(),
  },
  (table) => {
    return {
      unq: unique().on(table.playlistId, table.channelId),
    }
  },
)

// Type definitions
export type User = InferSelectModel<typeof users>
export type InsertUser = InferInsertModel<typeof users>

export type Channel = InferSelectModel<typeof channels>
export type InsertChannel = InferInsertModel<typeof channels>

// Add other schema definitions as needed
