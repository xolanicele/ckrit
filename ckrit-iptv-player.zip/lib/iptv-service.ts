"use server"

import type { Channel, M3UItem, Playlist } from "./types"
import { parse } from "iptv-playlist-parser"
import { v4 as uuidv4 } from "uuid"
import { getChannelsFromDb } from "@/app/actions"
import { getCachedChannelStatus, cacheChannelStatus } from "./redis"

// GitHub IPTV repository URL
const IPTV_PLAYLIST_URL = "https://iptv-org.github.io/iptv/index.m3u"
const COUNTRY_CODES_URL = "https://iptv-org.github.io/iptv/countries.json"

interface CountryInfo {
  name: string
  code: string
  languages: string[]
}

export async function fetchPlaylists(): Promise<Playlist[]> {
  // In a real app, this would fetch from a database
  // For demo purposes, we'll return hardcoded playlists
  return [
    {
      id: "iptv-org-all",
      name: "IPTV.org - All Channels",
      url: "https://iptv-org.github.io/iptv/index.m3u",
      description: "All channels from the IPTV.org repository",
      channelCount: 5000,
    },
    {
      id: "iptv-org-countries",
      name: "IPTV.org - By Country",
      url: "https://iptv-org.github.io/iptv/index.country.m3u",
      description: "Channels organized by country",
      channelCount: 5000,
    },
    {
      id: "iptv-org-categories",
      name: "IPTV.org - By Category",
      url: "https://iptv-org.github.io/iptv/index.category.m3u",
      description: "Channels organized by category",
      channelCount: 5000,
    },
    {
      id: "iptv-org-languages",
      name: "IPTV.org - By Language",
      url: "https://iptv-org.github.io/iptv/index.language.m3u",
      description: "Channels organized by language",
      channelCount: 5000,
    },
    {
      id: "iptv-org-sports",
      name: "IPTV.org - Sports",
      url: "https://iptv-org.github.io/iptv/categories/sports.m3u",
      description: "Sports channels from around the world",
      channelCount: 1200,
    },
  ]
}

export async function fetchChannels(playlistUrl?: string): Promise<Channel[]> {
  try {
    // If we're not specifying a playlist URL, get channels from database
    if (!playlistUrl) {
      return await getChannelsFromDb()
    }

    // Fetch country codes for mapping
    const countryCodesResponse = await fetch(COUNTRY_CODES_URL, {
      next: { revalidate: 3600 },
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })
    const countryCodes: CountryInfo[] = await countryCodesResponse.json()

    // Create a map for quick lookup
    const countryMap = new Map<string, string>()
    countryCodes.forEach((country) => {
      countryMap.set(country.code.toLowerCase(), country.name)
    })

    // Fetch the M3U playlist
    const response = await fetch(playlistUrl, {
      next: { revalidate: 3600 },
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })
    const m3uContent = await response.text()

    // Parse the M3U playlist
    const playlist = parse(m3uContent)

    // Convert M3U items to Channel objects and check if they're active
    const channelPromises = playlist.items.map(async (item: M3UItem) => {
      const countryCode = item.tvg.id?.split(".").pop() || ""
      const country = countryMap.get(countryCode) || ""
      const channelId = uuidv4()

      return {
        id: channelId,
        name: item.name,
        url: item.url,
        logo: item.tvg.logo,
        category: item.group.title,
        country: country,
        language: "", // Could be extracted if available
        isActive: await checkChannelStatus(channelId, item.url),
      }
    })

    // Process channels in batches to avoid overwhelming the server
    const batchSize = 50
    const channels: Channel[] = []

    for (let i = 0; i < channelPromises.length; i += batchSize) {
      const batch = channelPromises.slice(i, i + batchSize)
      const results = await Promise.all(batch)
      channels.push(...results)
    }

    // Filter out inactive channels
    const activeChannels = channels.filter((channel) => channel.isActive)

    return activeChannels
  } catch (error) {
    console.error("Error fetching IPTV channels:", error)
    return []
  }
}

async function checkChannelStatus(channelId: string, url: string): Promise<boolean> {
  try {
    // Check if we have a cached status
    const cachedStatus = await getCachedChannelStatus(channelId)
    if (cachedStatus !== null) {
      return cachedStatus
    }

    // Attempt to fetch the stream with a HEAD request and a timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    const response = await fetch(url, {
      method: "HEAD",
      signal: controller.signal,
      headers: {
        "User-Agent": "Mjeyi-IPTV-Player/1.0",
      },
    })

    clearTimeout(timeoutId)

    // Consider 2xx status codes as active
    const isActive = response.ok

    // Cache the result
    await cacheChannelStatus(channelId, isActive)

    return isActive
  } catch (error) {
    // Any error means the channel is not active
    await cacheChannelStatus(channelId, false)
    return false
  }
}
