// Helper to get Supabase environment variables
export const getSupabaseEnv = () => {
  return {
    supabaseUrl: process.env.SUPABASE_SUPABASE_URL || "",
    supabaseKey: process.env.SUPABASE_SUPABASE_ANON_KEY || "",
    supabaseServiceRoleKey: process.env.SUPABASE_SUPABASE_SERVICE_ROLE_KEY || "",
  }
}

// Helper to get client-side Supabase environment variables
export const getClientSupabaseEnv = () => {
  return {
    supabaseUrl: process.env.SUPABASE_NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_SUPABASE_URL || "",
    supabaseKey: proSUPABASE_NEXT_PUBLIC_SUPABASE_ANON_KEY_ANON_KEY || process.env.SUPABASE_SUPABASE_ANON_KEY || "",
  }
}
