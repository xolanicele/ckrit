"use server"

import { trackUnofficialStream, getUnofficialStreams } from "./redis"
import { addAlternativeStream } from "@/app/actions"

// Sources to search for streams
const STREAM_SOURCES = [
  {
    name: "StreamFinder",
    baseUrl: "https://example.com/api/streams",
    searchParam: "q",
  },
  {
    name: "LiveTV",
    baseUrl: "https://example.com/api/live",
    searchParam: "channel",
  },
  // Add more sources as needed
]

// Find unofficial streams for a channel
export async function findUnofficialStreams(channelName: string, channelId: string) {
  // First check Redis cache
  const cachedStreams = await getUnofficialStreams(channelName)

  if (cachedStreams.length > 0) {
    // Add streams to database if they're not already there
    for (const stream of cachedStreams) {
      if (Date.now() - stream.timestamp < 24 * 60 * 60 * 1000) {
        // Less than 24 hours old
        await addAlternativeStream(channelId, stream.url, "Unknown", stream.source)
      }
    }

    return cachedStreams
  }

  // Search for streams from various sources
  const foundStreams = []

  for (const source of STREAM_SOURCES) {
    try {
      const url = `${source.baseUrl}?${source.searchParam}=${encodeURIComponent(channelName)}`

      const response = await fetch(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        next: { revalidate: 3600 }, // Cache for 1 hour
      })

      if (!response.ok) continue

      const data = await response.json()

      // Process the response based on the source format
      // This is a simplified example - actual implementation would depend on API responses
      if (data.streams && Array.isArray(data.streams)) {
        for (const stream of data.streams) {
          if (stream.url) {
            foundStreams.push({
              url: stream.url,
              quality: stream.quality || "Unknown",
              source: source.name,
            })

            // Track in Redis
            await trackUnofficialStream(channelName, stream.url, source.name)

            // Add to database
            await addAlternativeStream(channelId, stream.url, stream.quality || "Unknown", source.name)
          }
        }
      }
    } catch (error) {
      console.error(`Error searching ${source.name}:`, error)
    }
  }

  return foundStreams
}

// Validate stream URL
export async function validateStreamUrl(url: string) {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    const response = await fetch(url, {
      method: "HEAD",
      signal: controller.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    clearTimeout(timeoutId)

    return response.ok
  } catch (error) {
    return false
  }
}

// Batch validate multiple streams
export async function batchValidateStreams(streams: { id: number; url: string }[]) {
  const results = await Promise.allSettled(
    streams.map(async (stream) => {
      const isValid = await validateStreamUrl(stream.url)
      return { id: stream.id, isValid }
    }),
  )

  return results
    .filter(
      (result): result is PromiseFulfilledResult<{ id: number; isValid: boolean }> => result.status === "fulfilled",
    )
    .map((result) => result.value)
}
