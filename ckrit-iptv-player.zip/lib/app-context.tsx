"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Channel, Playlist, UserPreferences } from "@/lib/types"
import {
  getUserFavorites,
  getUserWatchHistory,
  getUserSettings,
  saveUserSettings,
  addToWatchHistory,
} from "@/app/actions"

interface AppContextType {
  channels: Channel[]
  filteredChannels: Channel[]
  selectedChannel: Channel | null
  categories: string[]
  countries: string[]
  selectedCategory: string
  selectedCountry: string
  searchQuery: string
  loading: boolean
  sidebarOpen: boolean
  activeTab: string
  isSettingsOpen: boolean
  playlists: Playlist[]
  selectedPlaylist: Playlist | null
  userPreferences: UserPreferences
  isLoggedIn: boolean
  setChannels: (channels: Channel[]) => void
  setFilteredChannels: (channels: Channel[]) => void
  setSelectedChannel: (channel: Channel | null) => void
  setCategories: (categories: string[]) => void
  setCountries: (countries: string[]) => void
  setSelectedCategory: (category: string) => void
  setSelectedCountry: (country: string) => void
  setSearchQuery: (query: string) => void
  setLoading: (loading: boolean) => void
  setSidebarOpen: (open: boolean) => void
  setActiveTab: (tab: string) => void
  setIsSettingsOpen: (open: boolean) => void
  setPlaylists: (playlists: Playlist[]) => void
  setSelectedPlaylist: (playlist: Playlist | null) => void
  setUserPreferences: (preferences: UserPreferences | ((prev: UserPreferences) => UserPreferences)) => void
  setIsLoggedIn: (isLoggedIn: boolean) => void
  toggleFavorite: (channelId: string) => Promise<void>
  updateWatchHistory: (channel: Channel) => Promise<void>
}

const DEFAULT_PREFERENCES: UserPreferences = {
  theme: "dark",
  volume: 0.8,
  quality: "auto",
  favorites: [],
  history: [],
  lastChannel: null,
  lastPlaylist: null,
  bufferSize: "default",
  subtitleLanguage: "auto",
  subtitleSize: "medium",
  enablePiP: false,
  enableAdvancedBuffering: true,
  enableHardwareAcceleration: true,
  enableEPG: false,
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [channels, setChannels] = useState<Channel[]>([])
  const [filteredChannels, setFilteredChannels] = useState<Channel[]>([])
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null)
  const [categories, setCategories] = useState<string[]>([])
  const [countries, setCountries] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [selectedCountry, setSelectedCountry] = useState<string>("All")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [loading, setLoading] = useState<boolean>(true)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState("channels")
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [playlists, setPlaylists] = useState<Playlist[]>([])
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null)
  const [userPreferences, setUserPreferences] = useState<UserPreferences>(DEFAULT_PREFERENCES)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  // Load user data from database when logged in
  useEffect(() => {
    async function loadUserData() {
      try {
        // Load favorites
        const favorites = await getUserFavorites()

        // Load watch history
        const history = await getUserWatchHistory()

        // Load user settings
        const settings = await getUserSettings()

        if (settings) {
          setUserPreferences((prev) => ({
            ...prev,
            theme: settings.theme,
            volume: Number(settings.volume),
            quality: settings.quality,
            favorites: favorites,
            history: history.map((h) => ({
              channelId: h.channelId,
              name: h.channel.name,
              timestamp: h.watchedAt.toISOString(),
            })),
            lastChannel: settings.lastChannel,
            enablePiP: settings.enablePip,
            enableAdvancedBuffering: settings.enableAdvancedBuffering,
          }))

          // Apply saved theme
          document.documentElement.classList.toggle("dark", settings.theme === "dark")
        }

        setIsLoggedIn(true)
      } catch (error) {
        console.error("Failed to load user data:", error)
      }
    }

    loadUserData()
  }, [])

  // Save user settings to database when they change
  useEffect(() => {
    if (!isLoggedIn) return

    async function saveSettings() {
      try {
        await saveUserSettings({
          theme: userPreferences.theme,
          volume: userPreferences.volume,
          quality: userPreferences.quality,
          enablePip: userPreferences.enablePiP,
          enableAdvancedBuffering: userPreferences.enableAdvancedBuffering,
          lastChannel: userPreferences.lastChannel,
        })
      } catch (error) {
        console.error("Failed to save settings:", error)
      }
    }

    saveSettings()
  }, [userPreferences, isLoggedIn])

  // Toggle favorite in database
  const toggleFavorite = async (channelId: string) => {
    try {
      // Update local state immediately for responsive UI
      setUserPreferences((prev) => {
        const isFavorite = prev.favorites.includes(channelId)
        return {
          ...prev,
          favorites: isFavorite ? prev.favorites.filter((id) => id !== channelId) : [...prev.favorites, channelId],
        }
      })

      // Update database
      if (isLoggedIn) {
        await import("@/app/actions").then((actions) => actions.toggleFavorite(channelId))
      }
    } catch (error) {
      console.error("Failed to toggle favorite:", error)
    }
  }

  // Update watch history in database
  const updateWatchHistory = async (channel: Channel) => {
    try {
      // Update local state
      setUserPreferences((prev) => {
        const historyItem = {
          channelId: channel.id,
          name: channel.name,
          timestamp: new Date().toISOString(),
        }

        return {
          ...prev,
          lastChannel: channel.id,
          history: [historyItem, ...prev.history.filter((h) => h.channelId !== channel.id).slice(0, 19)],
        }
      })

      // Update database
      if (isLoggedIn) {
        await addToWatchHistory(channel.id)
      }
    } catch (error) {
      console.error("Failed to update watch history:", error)
    }
  }

  const value = {
    channels,
    filteredChannels,
    selectedChannel,
    categories,
    countries,
    selectedCategory,
    selectedCountry,
    searchQuery,
    loading,
    sidebarOpen,
    activeTab,
    isSettingsOpen,
    playlists,
    selectedPlaylist,
    userPreferences,
    isLoggedIn,
    setChannels,
    setFilteredChannels,
    setSelectedChannel,
    setCategories,
    setCountries,
    setSelectedCategory,
    setSelectedCountry,
    setSearchQuery,
    setLoading,
    setSidebarOpen,
    setActiveTab,
    setIsSettingsOpen,
    setPlaylists,
    setSelectedPlaylist,
    setUserPreferences,
    setIsLoggedIn,
    toggleFavorite,
    updateWatchHistory,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider")
  }
  return context
}
