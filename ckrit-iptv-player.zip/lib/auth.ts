import { cookies } from "next/headers"
import { kv } from "@vercel/kv"
import { getUserByEmail, createUser, getUserById } from "./db"
import { redirect } from "next/navigation"

const SESSION_COOKIE_NAME = "mjeyi_session"
const SESSION_PREFIX = "session:"
const SESSION_TTL = 60 * 60 * 24 * 7 // 1 week

// Create a session
async function createSession(userId: number, sessionData: any) {
  const sessionId = crypto.randomUUID()
  await kv.set(
    `${SESSION_PREFIX}${sessionId}`,
    JSON.stringify({
      userId,
      ...sessionData,
      createdAt: Date.now(),
    }),
    { ex: SESSION_TTL },
  )
  return sessionId
}

// Get session data
async function getSession(sessionId: string) {
  const session = await kv.get<string>(`${SESSION_PREFIX}${sessionId}`)
  return session ? JSON.parse(session) : null
}

// Delete session
async function deleteSession(sessionId: string) {
  await kv.del(`${SESSION_PREFIX}${sessionId}`)
}

export async function signIn(email: string, name: string) {
  // Get or create user
  let user = await getUserByEmail(email)

  if (!user) {
    user = await createUser(email, name)
  }

  // Create session
  const sessionId = await createSession(user.id, {
    email: user.email,
    name: user.name,
  })

  // Set session cookie
  cookies().set({
    name: SESSION_COOKIE_NAME,
    value: sessionId,
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
  })

  return user
}

export async function signOut() {
  const sessionId = cookies().get(SESSION_COOKIE_NAME)?.value

  if (sessionId) {
    await deleteSession(sessionId)
    cookies().delete(SESSION_COOKIE_NAME)
  }
}

export async function getUser() {
  const sessionId = cookies().get(SESSION_COOKIE_NAME)?.value

  if (!sessionId) {
    return null
  }

  const session = await getSession(sessionId)

  if (!session) {
    cookies().delete(SESSION_COOKIE_NAME)
    return null
  }

  return await getUserById(session.userId)
}

export async function requireAuth() {
  const user = await getUser()

  if (!user) {
    redirect("/login")
  }

  return user
}
