"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import type { Channel } from "@/lib/types"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Loader2,
  Heart,
  PictureInPicture,
  SkipForward,
  SkipBack,
  RotateCcw,
  Settings,
  Subtitles,
  Airplay,
  Cast,
  Share2,
  Info,
  Clock,
  Download,
  Tv,
  Eye,
  MoreHorizontal,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useToast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useHLSPlayer } from "@/hooks/use-enhanced-hls-player"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { addToWatchHistory, getAlternativeStreams, getCurrentProgram, voteForStream } from "@/app/actions"
import { getChannelViewerCount, trackChannelView } from "@/lib/redis"

interface EnhancedVideoPlayerProps {
  channel: Channel
  volume: number
  onVolumeChange: (volume: number) => void
  isFavorite: boolean
  onToggleFavorite: () => void
  quality: string
  enablePiP?: boolean
  enableAdvancedBuffering?: boolean
  enableTimeshift?: boolean
}

export default function EnhancedVideoPlayer({
  channel,
  volume,
  onVolumeChange,
  isFavorite,
  onToggleFavorite,
  quality,
  enablePiP = false,
  enableAdvancedBuffering = true,
  enableTimeshift = false,
}: EnhancedVideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const progressBarRef = useRef<HTMLDivElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [currentQuality, setCurrentQuality] = useState<string>(quality || "auto")
  const [bufferingProgress, setBufferingProgress] = useState(0)
  const [isBuffering, setIsBuffering] = useState(false)
  const [showSubtitles, setShowSubtitles] = useState(false)
  const [showInfo, setShowInfo] = useState(false)
  const [showAlternativeStreams, setShowAlternativeStreams] = useState(false)
  const [alternativeStreams, setAlternativeStreams] = useState<any[]>([])
  const [currentProgram, setCurrentProgram] = useState<any>(null)
  const [viewerCount, setViewerCount] = useState<number>(0)
  const [networkStats, setNetworkStats] = useState({
    bitrate: 0,
    droppedFrames: 0,
    bufferHealth: 0,
  })
  const [isTimeshiftMode, setIsTimeshiftMode] = useState(false)
  const [timeshiftPosition, setTimeshiftPosition] = useState(0)
  const [timeshiftDuration, setTimeshiftDuration] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([])
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null)

  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const viewerCountIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const watchHistoryIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const { toast } = useToast()

  const {
    initHLS,
    destroyHLS,
    changeQuality,
    getCurrentStats,
    seekTo,
    toggleTimeshift,
    isTimeshiftAvailable,
    getTimeshiftDuration,
    getTimeshiftPosition,
  } = useHLSPlayer({
    videoRef,
    onError: (errorMsg) => {
      setError(errorMsg || "Failed to play this stream")
      setIsLoading(false)
    },
    onLoading: () => setIsLoading(true),
    onReady: () => setIsLoading(false),
    onBuffering: (isBuffering) => setIsBuffering(isBuffering),
    onBufferingProgress: (progress) => setBufferingProgress(progress),
    enableAdvancedBuffering,
    enableTimeshift,
  })

  // Handle channel change
  useEffect(() => {
    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)
    setIsBuffering(false)
    setIsTimeshiftMode(false)
    setTimeshiftPosition(0)
    setTimeshiftDuration(0)

    if (videoRef.current) {
      // Clean up previous HLS instance
      destroyHLS()

      // Initialize new HLS instance with the new channel
      initHLS(channel.url, currentQuality)

      // Track channel view
      trackChannelView(channel.id)

      // Load alternative streams
      loadAlternativeStreams()

      // Load current program
      loadCurrentProgram()
    }

    // Update stats periodically
    const statsInterval = setInterval(() => {
      if (isPlaying && !isLoading) {
        const stats = getCurrentStats()
        setNetworkStats(stats)
      }
    }, 2000)

    // Update viewer count periodically
    viewerCountIntervalRef.current = setInterval(async () => {
      try {
        const count = await getChannelViewerCount(channel.id)
        setViewerCount(count || 0)
      } catch (error) {
        console.error("Error getting viewer count:", error)
      }
    }, 10000)

    // Update watch history periodically
    watchHistoryIntervalRef.current = setInterval(async () => {
      if (isPlaying && videoRef.current) {
        await addToWatchHistory(channel.id, Math.floor(videoRef.current.currentTime), 0)
      }
    }, 60000) // Update every minute

    return () => {
      clearInterval(statsInterval)
      if (viewerCountIntervalRef.current) clearInterval(viewerCountIntervalRef.current)
      if (watchHistoryIntervalRef.current) clearInterval(watchHistoryIntervalRef.current)
      destroyHLS()
      stopRecording()
    }
  }, [channel, currentQuality, destroyHLS, getCurrentStats, initHLS, isLoading, isPlaying])

  // Load alternative streams
  const loadAlternativeStreams = async () => {
    try {
      const streams = await getAlternativeStreams(channel.id)
      setAlternativeStreams(streams || [])
    } catch (error) {
      console.error("Error loading alternative streams:", error)
    }
  }

  // Load current program
  const loadCurrentProgram = async () => {
    try {
      const program = await getCurrentProgram(channel.id)
      setCurrentProgram(program)
    } catch (error) {
      console.error("Error loading current program:", error)
    }
  }

  // Apply volume from props
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume
    }
  }, [volume])

  // Auto-hide controls
  useEffect(() => {
    const hideControls = () => {
      if (isPlaying && !isBuffering) {
        setShowControls(false)
      }
    }

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }

    if (showControls) {
      controlsTimeoutRef.current = setTimeout(hideControls, 3000)
    }

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }
    }
  }, [showControls, isPlaying, isBuffering])

  // Handle fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Update timeshift info
  useEffect(() => {
    if (isTimeshiftMode && videoRef.current) {
      const updateTimeshiftInfo = () => {
        setTimeshiftPosition(getTimeshiftPosition())
        setTimeshiftDuration(getTimeshiftDuration())
      }

      const interval = setInterval(updateTimeshiftInfo, 1000)
      updateTimeshiftInfo()

      return () => clearInterval(interval)
    }
  }, [isTimeshiftMode, getTimeshiftPosition, getTimeshiftDuration])

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play().catch((err) => {
          setError("Failed to play this stream. It may be unavailable.")
          console.error("Play error:", err)
          toast({
            title: "Playback Error",
            description: "Failed to play this stream. It may be unavailable.",
            variant: "destructive",
          })
        })
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    if (videoRef.current) {
      videoRef.current.volume = newVolume
    }
    onVolumeChange(newVolume)
  }

  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (document.fullscreenElement) {
      document.exitFullscreen()
    } else {
      containerRef.current.requestFullscreen()
    }
  }

  const togglePictureInPicture = async () => {
    if (!videoRef.current || !enablePiP) return

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture()
      } else {
        await videoRef.current.requestPictureInPicture()
        toast({
          title: "Picture-in-Picture mode",
          description: "You can now browse while watching",
          duration: 3000,
        })
      }
    } catch (error) {
      console.error("PiP error:", error)
      toast({
        title: "Feature not supported",
        description: "Picture-in-Picture is not supported in your browser",
        variant: "destructive",
      })
    }
  }

  const reloadStream = () => {
    if (!videoRef.current) return

    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)

    // Reinitialize HLS
    destroyHLS()
    initHLS(channel.url, currentQuality)

    toast({
      title: "Reloading stream",
      description: "Attempting to refresh the connection",
      duration: 2000,
    })
  }

  const skipForward = () => {
    if (!videoRef.current) return

    if (isTimeshiftMode) {
      seekTo(timeshiftPosition + 30)
    } else {
      // For live streams, this might not do much, but for VOD content it would
      videoRef.current.currentTime += 10
    }

    toast({
      title: "Skipped forward",
      description: isTimeshiftMode ? "+30 seconds" : "+10 seconds",
      duration: 1000,
    })
  }

  const skipBackward = () => {
    if (!videoRef.current || !isTimeshiftMode) return

    seekTo(Math.max(0, timeshiftPosition - 30))

    toast({
      title: "Skipped backward",
      description: "-30 seconds",
      duration: 1000,
    })
  }

  const handleQualityChange = (quality: string) => {
    setCurrentQuality(quality)
    changeQuality(quality)
    toast({
      title: "Quality changed",
      description: `Switched to ${quality} quality`,
      duration: 2000,
    })
  }

  const toggleSubtitles = () => {
    setShowSubtitles(!showSubtitles)
    toast({
      title: showSubtitles ? "Subtitles disabled" : "Subtitles enabled",
      duration: 1000,
    })
  }

  const handleCast = () => {
    toast({
      title: "Casting",
      description: "Looking for devices...",
      duration: 2000,
    })

    // This would be implemented with the actual Chromecast API
    setTimeout(() => {
      toast({
        title: "Cast unavailable",
        description: "No cast devices found or feature not supported",
        variant: "destructive",
      })
    }, 2000)
  }

  const handleAirplay = () => {
    if (videoRef.current && "webkitShowPlaybackTargetPicker" in videoRef.current) {
      // @ts-ignore - TypeScript doesn't know about this Safari-specific API
      videoRef.current.webkitShowPlaybackTargetPicker()
    } else {
      toast({
        title: "AirPlay unavailable",
        description: "This feature is only available in Safari",
        variant: "destructive",
      })
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Watching ${channel.name} on Mjeyi's IPTV Services`,
          text: `Check out ${channel.name} on Mjeyi's IPTV Services!`,
          url: window.location.href,
        })
      } catch (error) {
        console.error("Share error:", error)
      }
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "Channel link copied to clipboard",
        duration: 2000,
      })
    }
  }

  const handleTimeshiftToggle = () => {
    if (!enableTimeshift) {
      toast({
        title: "Timeshift not enabled",
        description: "Enable timeshift in settings to use this feature",
        variant: "destructive",
      })
      return
    }

    const success = toggleTimeshift()
    setIsTimeshiftMode(!isTimeshiftMode)

    if (success) {
      toast({
        title: isTimeshiftMode ? "Live mode" : "Timeshift mode",
        description: isTimeshiftMode ? "Switched to live stream" : "You can now rewind and pause the stream",
        duration: 2000,
      })
    } else {
      toast({
        title: "Timeshift unavailable",
        description: "This channel does not support timeshift functionality",
        variant: "destructive",
      })
    }
  }

  const handleTimeshiftSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || !isTimeshiftMode) return

    const rect = progressBarRef.current.getBoundingClientRect()
    const position = (e.clientX - rect.left) / rect.width
    const seekPosition = position * timeshiftDuration

    seekTo(seekPosition)
  }

  const startRecording = () => {
    if (!videoRef.current || isRecording) return

    try {
      // @ts-ignore - TypeScript doesn't know about captureStream
      const stream = videoRef.current.captureStream()
      const recorder = new MediaRecorder(stream, { mimeType: "video/webm" })

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          setRecordedChunks((prev) => [...prev, e.data])
        }
      }

      recorder.start(1000) // Collect data every second
      setMediaRecorder(recorder)
      setIsRecording(true)
      setRecordingTime(0)
      setRecordedChunks([])

      // Update recording time
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)

      toast({
        title: "Recording started",
        description: "Recording the current stream",
        duration: 2000,
      })
    } catch (error) {
      console.error("Recording error:", error)
      toast({
        title: "Recording failed",
        description: "Failed to start recording. This feature may not be supported in your browser.",
        variant: "destructive",
      })
    }
  }

  const stopRecording = () => {
    if (!mediaRecorder || !isRecording) return

    mediaRecorder.stop()
    setIsRecording(false)

    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current)
      recordingIntervalRef.current = null
    }

    toast({
      title: "Recording stopped",
      description: "Your recording is ready to download",
      duration: 2000,
    })
  }

  const downloadRecording = () => {
    if (recordedChunks.length === 0) return

    const blob = new Blob(recordedChunks, { type: "video/webm" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${channel.name}-${new Date().toISOString()}.webm`
    a.click()

    URL.revokeObjectURL(url)

    toast({
      title: "Download started",
      description: "Your recording is being downloaded",
      duration: 2000,
    })
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleUseAlternativeStream = async (streamUrl: string) => {
    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)

    // Reinitialize HLS with alternative stream
    destroyHLS()
    initHLS(streamUrl, currentQuality)

    setShowAlternativeStreams(false)

    toast({
      title: "Alternative stream",
      description: "Switched to alternative stream source",
      duration: 2000,
    })
  }

  const handleVoteForStream = async (streamId: number) => {
    const result = await voteForStream(streamId)

    if (result.success) {
      toast({
        title: "Vote recorded",
        description: "Thank you for your feedback",
        duration: 2000,
      })

      // Refresh alternative streams
      loadAlternativeStreams()
    } else {
      toast({
        title: "Vote failed",
        description: result.error || "Failed to record your vote",
        variant: "destructive",
      })
    }
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full flex flex-col bg-black"
      onMouseMove={() => {
        setShowControls(true)
        if (controlsTimeoutRef.current) {
          clearTimeout(controlsTimeoutRef.current)
        }
        controlsTimeoutRef.current = setTimeout(() => {
          if (isPlaying && !isBuffering) {
            setShowControls(false)
          }
        }, 3000)
      }}
    >
      <div className="relative flex-1 bg-black">
        <AnimatePresence>
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70 z-10"
            >
              <Loader2 className="w-12 h-12 animate-spin text-purple-500" />
              <div className="mt-4 w-64 bg-zinc-800 rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  initial={{ width: "0%" }}
                  animate={{ width: `${bufferingProgress}%` }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                />
              </div>
              <p className="mt-2 text-sm text-zinc-400">Buffering stream...</p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-80 z-10"
            >
              <div className="text-center p-6 bg-zinc-900/80 backdrop-blur-md rounded-lg max-w-md">
                <p className="text-red-500 text-xl mb-4">{error}</p>
                <div className="flex gap-2 justify-center">
                  <Button onClick={reloadStream} className="flex items-center gap-2">
                    <RotateCcw className="w-4 h-4" />
                    Try Again
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowAlternativeStreams(true)}
                    className="flex items-center gap-2"
                  >
                    <Tv className="w-4 h-4" />
                    Alternative Sources
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          autoPlay
          playsInline
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => setIsBuffering(false)}
        >
          {showSubtitles && (
            <track kind="subtitles" src={`/api/subtitles?channel=${channel.id}`} srcLang="en" label="English" default />
          )}
          Your browser does not support the video tag.
        </video>

        {/* Channel info overlay */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-zinc-800 rounded overflow-hidden flex-shrink-0">
                  {channel.logo ? (
                    <img
                      src={channel.logo || "/placeholder.svg"}
                      alt={channel.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-bold">
                      {channel.name.substring(0, 2).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-semibold line-clamp-1">{channel.name}</h2>
                  <div className="flex text-sm text-zinc-400 mt-1">
                    {channel.country && <span className="mr-2">{channel.country}</span>}
                    {channel.category && <span>{channel.category}</span>}
                    {currentProgram && <span className="ml-2 text-purple-400">• {currentProgram.title}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 px-2 py-1 bg-zinc-800/50 rounded-full text-xs">
                    <Eye className="h-3 w-3" />
                    <span>{viewerCount}</span>
                  </div>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={onToggleFavorite}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{isFavorite ? "Remove from favorites" : "Add to favorites"}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Timeshift progress bar */}
        {isTimeshiftMode && (
          <div
            ref={progressBarRef}
            className="absolute bottom-16 left-4 right-4 h-2 bg-zinc-800/70 rounded-full overflow-hidden cursor-pointer z-20"
            onClick={handleTimeshiftSeek}
          >
            <div
              className="h-full bg-purple-500"
              style={{ width: `${(timeshiftPosition / timeshiftDuration) * 100}%` }}
            />
            <div className="absolute top-4 left-0 right-0 flex justify-between text-xs text-zinc-400">
              <span>-{formatTime(timeshiftDuration - timeshiftPosition)}</span>
              <span>Live</span>
            </div>
          </div>
        )}

        {/* Video controls */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent z-10"
            >
              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={togglePlay}
                        disabled={isLoading}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isPlaying ? "Pause" : "Play"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                {isTimeshiftMode && (
                  <>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={skipBackward}
                            className="text-white hover:bg-zinc-800/50"
                          >
                            <SkipBack className="h-5 w-5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Skip back 30s</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </>
                )}

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={skipForward}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        <SkipForward className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Skip forward {isTimeshiftMode ? "30s" : "10s"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleMute}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isMuted ? "Unmute" : "Mute"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <div className="w-24 mx-2">
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    min={0}
                    max={1}
                    step={0.01}
                    onValueChange={handleVolumeChange}
                    className="[&>span:first-child]:h-1.5 [&>span:first-child]:bg-white/30 [&_[role=slider]]:bg-purple-500 [&_[role=slider]]:w-3 [&_[role=slider]]:h-3 [&_[role=slider]]:border-0 [&>span:first-child_span]:bg-purple-500"
                  />
                </div>

                {enableTimeshift && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant={isTimeshiftMode ? "secondary" : "ghost"}
                          size="icon"
                          onClick={handleTimeshiftToggle}
                          className={cn(
                            "text-white hover:bg-zinc-800/50",
                            isTimeshiftMode && "bg-purple-500/20 text-purple-400",
                          )}
                        >
                          <Clock className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{isTimeshiftMode ? "Return to live" : "Enable timeshift"}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}

                {isRecording ? (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={stopRecording}
                          className="bg-red-500/20 text-red-400 hover:bg-red-500/30"
                        >
                          <span className="animate-pulse mr-1 h-2 w-2 rounded-full bg-red-500"></span>
                          {formatTime(recordingTime)}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Stop recording</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ) : recordedChunks.length > 0 ? (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={downloadRecording}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Download recording</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ) : null}

                <div className="ml-auto flex items-center gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleSubtitles}
                          className={cn(
                            "text-white hover:bg-zinc-800/50",
                            showSubtitles && "bg-purple-500/20 text-purple-400",
                          )}
                        >
                          <Subtitles className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{showSubtitles ? "Hide subtitles" : "Show subtitles"}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setShowInfo(!showInfo)}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Info className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Stream information</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <DropdownMenu>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800/50">
                              <Settings className="h-5 w-5" />
                            </Button>
                          </DropdownMenuTrigger>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Quality settings</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800">
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("auto")}
                        className={cn(currentQuality === "auto" && "bg-zinc-800")}
                      >
                        Auto Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("high")}
                        className={cn(currentQuality === "high" && "bg-zinc-800")}
                      >
                        High Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("medium")}
                        className={cn(currentQuality === "medium" && "bg-zinc-800")}
                      >
                        Medium Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("low")}
                        className={cn(currentQuality === "low" && "bg-zinc-800")}
                      >
                        Low Quality
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <DropdownMenu>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800/50">
                              <MoreHorizontal className="h-5 w-5" />
                            </Button>
                          </DropdownMenuTrigger>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>More options</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <DropdownMenuContent align="end" className="w-48 bg-zinc-900 border-zinc-800">
                      <DropdownMenuItem onClick={() => setShowAlternativeStreams(true)}>
                        <Tv className="h-4 w-4 mr-2" />
                        Alternative Sources
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={isRecording ? stopRecording : startRecording}>
                        {isRecording ? (
                          <>
                            <span className="h-4 w-4 mr-2 flex items-center justify-center">■</span>
                            Stop Recording
                          </>
                        ) : (
                          <>
                            <span className="h-4 w-4 mr-2 flex items-center justify-center">●</span>
                            Start Recording
                          </>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleCast}>
                        <Cast className="h-4 w-4 mr-2" />
                        Cast to Device
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleAirplay}>
                        <Airplay className="h-4 w-4 mr-2" />
                        AirPlay
                      </DropdownMenuItem>
                      {enablePiP && (
                        <DropdownMenuItem onClick={togglePictureInPicture}>
                          <PictureInPicture className="h-4 w-4 mr-2" />
                          Picture-in-Picture
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleFullscreen}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Maximize className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Fullscreen</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Buffering indicator */}
        <AnimatePresence>
          {isBuffering && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-sm p-3 rounded-full"
            >
              <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Stream info dialog */}
      <Dialog open={showInfo} onOpenChange={setShowInfo}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Stream Information</DialogTitle>
            <DialogDescription className="text-zinc-400">Technical details about the current stream</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Bitrate</span>
                <span className="font-mono">{(networkStats.bitrate / 1000).toFixed(2)} Mbps</span>
              </div>
              <Progress value={Math.min((networkStats.bitrate / 10000) * 100, 100)} className="h-1" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Buffer Health</span>
                <span className="font-mono">{networkStats.bufferHealth.toFixed(2)}s</span>
              </div>
              <Progress
                value={Math.min((networkStats.bufferHealth / 10) * 100, 100)}
                className={cn(
                  "h-1",
                  networkStats.bufferHealth < 1
                    ? "bg-red-900"
                    : networkStats.bufferHealth < 3
                      ? "bg-yellow-900"
                      : "bg-green-900",
                )}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Dropped Frames</span>
                <span className="font-mono">{networkStats.droppedFrames}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-zinc-400 mb-1">Stream URL</p>
                <p className="font-mono text-xs truncate">{channel.url}</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Quality</p>
                <p>{currentQuality}</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Format</p>
                <p>HLS (M3U8)</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Player</p>
                <p>Mjeyi Enhanced HLS Player</p>
              </div>
              {currentProgram && (
                <>
                  <div className="col-span-2">
                    <p className="text-zinc-400 mb-1">Current Program</p>
                    <p className="font-medium">{currentProgram.title}</p>
                    {currentProgram.description && (
                      <p className="text-xs text-zinc-400 mt-1">{currentProgram.description}</p>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Alternative streams dialog */}
      <Dialog open={showAlternativeStreams} onOpenChange={setShowAlternativeStreams}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Alternative Stream Sources</DialogTitle>
            <DialogDescription className="text-zinc-400">
              Try these alternative sources if the main stream is not working
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            {alternativeStreams.length === 0 ? (
              <div className="text-center py-8">
                <Tv className="h-12 w-12 mx-auto text-zinc-700 mb-4" />
                <p className="text-zinc-400">No alternative streams available</p>
              </div>
            ) : (
              alternativeStreams.map((stream) => (
                <div key={stream.id} className="p-3 bg-zinc-800/50 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <p className="font-medium">
                        {stream.source || "Alternative Source"}
                        {stream.quality && ` - ${stream.quality}`}
                      </p>
                      <p className="text-xs text-zinc-400">
                        {stream.user_submitted ? "User submitted" : "Official source"}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleVoteForStream(stream.id)}
                        className="text-zinc-400 hover:text-white"
                      >
                        <span className="text-xs mr-1">👍</span> {stream.votes}
                      </Button>
                      <Button variant="secondary" size="sm" onClick={() => handleUseAlternativeStream(stream.url)}>
                        Use
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
