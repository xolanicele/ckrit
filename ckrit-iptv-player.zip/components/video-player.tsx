"use client"

import { useEffect, useRef, useState } from "react"
import type { Channel } from "@/lib/types"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Loader2,
  Heart,
  PictureInPicture,
  SkipForward,
  RotateCcw,
  Settings,
  Subtitles,
  Airplay,
  Cast,
  Share2,
  Info,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useToast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useHLSPlayer } from "@/hooks/use-hls-player"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"

interface VideoPlayerProps {
  channel: Channel
  volume: number
  onVolumeChange: (volume: number) => void
  isFavorite: boolean
  onToggleFavorite: () => void
  quality: string
  enablePiP?: boolean
  enableAdvancedBuffering?: boolean
}

export default function VideoPlayer({
  channel,
  volume,
  onVolumeChange,
  isFavorite,
  onToggleFavorite,
  quality,
  enablePiP = false,
  enableAdvancedBuffering = true,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [currentQuality, setCurrentQuality] = useState<string>(quality || "auto")
  const [bufferingProgress, setBufferingProgress] = useState(0)
  const [isBuffering, setIsBuffering] = useState(false)
  const [showSubtitles, setShowSubtitles] = useState(false)
  const [showInfo, setShowInfo] = useState(false)
  const [networkStats, setNetworkStats] = useState({
    bitrate: 0,
    droppedFrames: 0,
    bufferHealth: 0,
  })
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const { toast } = useToast()

  const { initHLS, destroyHLS, changeQuality, getCurrentStats } = useHLSPlayer({
    videoRef,
    onError: (errorMsg) => {
      setError(errorMsg || "Failed to play this stream")
      setIsLoading(false)
    },
    onLoading: () => setIsLoading(true),
    onReady: () => setIsLoading(false),
    onBuffering: (isBuffering) => setIsBuffering(isBuffering),
    onBufferingProgress: (progress) => setBufferingProgress(progress),
    enableAdvancedBuffering,
  })

  // Handle channel change
  useEffect(() => {
    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)
    setIsBuffering(false)

    if (videoRef.current) {
      // Clean up previous HLS instance
      destroyHLS()

      // Initialize new HLS instance with the new channel
      initHLS(channel.url, currentQuality)
    }

    // Update stats periodically
    const statsInterval = setInterval(() => {
      if (isPlaying && !isLoading) {
        const stats = getCurrentStats()
        setNetworkStats(stats)
      }
    }, 2000)

    return () => {
      clearInterval(statsInterval)
      destroyHLS()
    }
  }, [channel, currentQuality, destroyHLS, getCurrentStats, initHLS, isLoading, isPlaying])

  // Apply volume from props
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume
    }
  }, [volume])

  // Auto-hide controls
  useEffect(() => {
    const hideControls = () => {
      if (isPlaying && !isBuffering) {
        setShowControls(false)
      }
    }

    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }

    if (showControls) {
      controlsTimeoutRef.current = setTimeout(hideControls, 3000)
    }

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }
    }
  }, [showControls, isPlaying, isBuffering])

  // Handle fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play().catch((err) => {
          setError("Failed to play this stream. It may be unavailable.")
          console.error("Play error:", err)
          toast({
            title: "Playback Error",
            description: "Failed to play this stream. It may be unavailable.",
            variant: "destructive",
          })
        })
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    if (videoRef.current) {
      videoRef.current.volume = newVolume
    }
    onVolumeChange(newVolume)
  }

  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (document.fullscreenElement) {
      document.exitFullscreen()
    } else {
      containerRef.current.requestFullscreen()
    }
  }

  const togglePictureInPicture = async () => {
    if (!videoRef.current || !enablePiP) return

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture()
      } else {
        await videoRef.current.requestPictureInPicture()
        toast({
          title: "Picture-in-Picture mode",
          description: "You can now browse while watching",
          duration: 3000,
        })
      }
    } catch (error) {
      console.error("PiP error:", error)
      toast({
        title: "Feature not supported",
        description: "Picture-in-Picture is not supported in your browser",
        variant: "destructive",
      })
    }
  }

  const reloadStream = () => {
    if (!videoRef.current) return

    setIsLoading(true)
    setError(null)
    setBufferingProgress(0)

    // Reinitialize HLS
    destroyHLS()
    initHLS(channel.url, currentQuality)

    toast({
      title: "Reloading stream",
      description: "Attempting to refresh the connection",
      duration: 2000,
    })
  }

  const skipForward = () => {
    if (!videoRef.current) return

    // For live streams, this might not do much, but for VOD content it would
    videoRef.current.currentTime += 10
    toast({
      title: "Skipped forward",
      description: "+10 seconds",
      duration: 1000,
    })
  }

  const handleQualityChange = (quality: string) => {
    setCurrentQuality(quality)
    changeQuality(quality)
    toast({
      title: "Quality changed",
      description: `Switched to ${quality} quality`,
      duration: 2000,
    })
  }

  const toggleSubtitles = () => {
    setShowSubtitles(!showSubtitles)
    toast({
      title: showSubtitles ? "Subtitles disabled" : "Subtitles enabled",
      duration: 1000,
    })
  }

  const handleCast = () => {
    toast({
      title: "Casting",
      description: "Looking for devices...",
      duration: 2000,
    })

    // This would be implemented with the actual Chromecast API
    setTimeout(() => {
      toast({
        title: "Cast unavailable",
        description: "No cast devices found or feature not supported",
        variant: "destructive",
      })
    }, 2000)
  }

  const handleAirplay = () => {
    if (videoRef.current && "webkitShowPlaybackTargetPicker" in videoRef.current) {
      // @ts-ignore - TypeScript doesn't know about this Safari-specific API
      videoRef.current.webkitShowPlaybackTargetPicker()
    } else {
      toast({
        title: "AirPlay unavailable",
        description: "This feature is only available in Safari",
        variant: "destructive",
      })
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Watching ${channel.name} on Mjeyi's IPTV Services`,
          text: `Check out ${channel.name} on Mjeyi's IPTV Services!`,
          url: window.location.href,
        })
      } catch (error) {
        console.error("Share error:", error)
      }
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "Channel link copied to clipboard",
        duration: 2000,
      })
    }
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full flex flex-col bg-black"
      onMouseMove={() => {
        setShowControls(true)
        if (controlsTimeoutRef.current) {
          clearTimeout(controlsTimeoutRef.current)
        }
        controlsTimeoutRef.current = setTimeout(() => {
          if (isPlaying && !isBuffering) {
            setShowControls(false)
          }
        }, 3000)
      }}
    >
      <div className="relative flex-1 bg-black">
        <AnimatePresence>
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70 z-10"
            >
              <Loader2 className="w-12 h-12 animate-spin text-purple-500" />
              <div className="mt-4 w-64 bg-zinc-800 rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  initial={{ width: "0%" }}
                  animate={{ width: `${bufferingProgress}%` }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                />
              </div>
              <p className="mt-2 text-sm text-zinc-400">Buffering stream...</p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-80 z-10"
            >
              <div className="text-center p-6 bg-zinc-900/80 backdrop-blur-md rounded-lg max-w-md">
                <p className="text-red-500 text-xl mb-4">{error}</p>
                <div className="flex gap-2 justify-center">
                  <Button onClick={reloadStream} className="flex items-center gap-2">
                    <RotateCcw className="w-4 h-4" />
                    Try Again
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          autoPlay
          playsInline
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => setIsBuffering(false)}
        >
          {showSubtitles && (
            <track kind="subtitles" src={`/api/subtitles?channel=${channel.id}`} srcLang="en" label="English" default />
          )}
          Your browser does not support the video tag.
        </video>

        {/* Channel info overlay */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-zinc-800 rounded overflow-hidden flex-shrink-0">
                  {channel.logo ? (
                    <img
                      src={channel.logo || "/placeholder.svg"}
                      alt={channel.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-bold">
                      {channel.name.substring(0, 2).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-semibold line-clamp-1">{channel.name}</h2>
                  <div className="flex text-sm text-zinc-400 mt-1">
                    {channel.country && <span className="mr-2">{channel.country}</span>}
                    {channel.category && <span>{channel.category}</span>}
                  </div>
                </div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={onToggleFavorite}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isFavorite ? "Remove from favorites" : "Add to favorites"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Video controls */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent z-10"
            >
              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={togglePlay}
                        disabled={isLoading}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isPlaying ? "Pause" : "Play"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={skipForward}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        <SkipForward className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Skip forward 10s</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={toggleMute}
                        className="text-white hover:bg-zinc-800/50"
                      >
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isMuted ? "Unmute" : "Mute"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <div className="w-24 mx-2">
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    min={0}
                    max={1}
                    step={0.01}
                    onValueChange={handleVolumeChange}
                    className="[&>span:first-child]:h-1.5 [&>span:first-child]:bg-white/30 [&_[role=slider]]:bg-purple-500 [&_[role=slider]]:w-3 [&_[role=slider]]:h-3 [&_[role=slider]]:border-0 [&>span:first-child_span]:bg-purple-500"
                  />
                </div>

                <div className="ml-auto flex items-center gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleSubtitles}
                          className={cn(
                            "text-white hover:bg-zinc-800/50",
                            showSubtitles && "bg-purple-500/20 text-purple-400",
                          )}
                        >
                          <Subtitles className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{showSubtitles ? "Hide subtitles" : "Show subtitles"}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setShowInfo(!showInfo)}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Info className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Stream information</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <DropdownMenu>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-white hover:bg-zinc-800/50">
                              <Settings className="h-5 w-5" />
                            </Button>
                          </DropdownMenuTrigger>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Quality settings</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800">
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("auto")}
                        className={cn(currentQuality === "auto" && "bg-zinc-800")}
                      >
                        Auto Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("high")}
                        className={cn(currentQuality === "high" && "bg-zinc-800")}
                      >
                        High Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("medium")}
                        className={cn(currentQuality === "medium" && "bg-zinc-800")}
                      >
                        Medium Quality
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleQualityChange("low")}
                        className={cn(currentQuality === "low" && "bg-zinc-800")}
                      >
                        Low Quality
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={handleShare}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Share2 className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Share</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={handleCast}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Cast className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Cast to device</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={handleAirplay}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Airplay className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>AirPlay</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  {enablePiP && (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={togglePictureInPicture}
                            className="text-white hover:bg-zinc-800/50"
                          >
                            <PictureInPicture className="h-5 w-5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Picture-in-Picture</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={toggleFullscreen}
                          className="text-white hover:bg-zinc-800/50"
                        >
                          <Maximize className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Fullscreen</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Buffering indicator */}
        <AnimatePresence>
          {isBuffering && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-sm p-3 rounded-full"
            >
              <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Stream info dialog */}
      <Dialog open={showInfo} onOpenChange={setShowInfo}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Stream Information</DialogTitle>
            <DialogDescription className="text-zinc-400">Technical details about the current stream</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Bitrate</span>
                <span className="font-mono">{(networkStats.bitrate / 1000).toFixed(2)} Mbps</span>
              </div>
              <Progress value={Math.min((networkStats.bitrate / 10000) * 100, 100)} className="h-1" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Buffer Health</span>
                <span className="font-mono">{networkStats.bufferHealth.toFixed(2)}s</span>
              </div>
              <Progress
                value={Math.min((networkStats.bufferHealth / 10) * 100, 100)}
                className={cn(
                  "h-1",
                  networkStats.bufferHealth < 1
                    ? "bg-red-900"
                    : networkStats.bufferHealth < 3
                      ? "bg-yellow-900"
                      : "bg-green-900",
                )}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Dropped Frames</span>
                <span className="font-mono">{networkStats.droppedFrames}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-zinc-400 mb-1">Stream URL</p>
                <p className="font-mono text-xs truncate">{channel.url}</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Quality</p>
                <p>{currentQuality}</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Format</p>
                <p>HLS (M3U8)</p>
              </div>
              <div>
                <p className="text-zinc-400 mb-1">Player</p>
                <p>Mjeyi HLS Player</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
