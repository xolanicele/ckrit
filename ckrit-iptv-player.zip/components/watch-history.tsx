"use client"

import type { Channel, HistoryItem } from "@/lib/types"
import { Clock, Trash2 } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { formatDistanceToNow } from "date-fns"

interface WatchHistoryProps {
  history: HistoryItem[]
  channels: Channel[]
  onChannelSelect: (channel: Channel) => void
  onClearHistory: () => void
}

export default function WatchHistory({ history, channels, onChannelSelect, onClearHistory }: WatchHistoryProps) {
  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring" }}
          className="flex flex-col items-center"
        >
          <Clock className="h-16 w-16 text-zinc-700 mb-4" />
          <h3 className="text-lg font-medium mb-2">No watch history</h3>
          <p className="text-sm text-zinc-400 max-w-xs">Your recently watched channels will appear here</p>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 flex justify-between items-center border-b border-zinc-800/50">
        <h3 className="font-medium">Recently Watched</h3>
        <Button variant="ghost" size="sm" onClick={onClearHistory} className="text-zinc-400 hover:text-white">
          <Trash2 className="h-4 w-4 mr-1" />
          Clear
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/50">
        {history.map((item, index) => {
          const channel = channels.find((c) => c.id === item.channelId)
          if (!channel) return null

          return (
            <motion.button
              key={`${item.channelId}-${item.timestamp}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03, type: "spring", damping: 25, stiffness: 300 }}
              className="w-full text-left p-4 hover:bg-zinc-800/50 transition-colors flex items-center gap-3"
              onClick={() => onChannelSelect(channel)}
            >
              <div className="flex-shrink-0 w-10 h-10 bg-zinc-800 rounded overflow-hidden flex items-center justify-center">
                {channel.logo ? (
                  <img
                    src={channel.logo || "/placeholder.svg"}
                    alt={channel.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=40&width=40"
                    }}
                  />
                ) : (
                  <span className="text-xs font-bold">{channel.name.substring(0, 2).toUpperCase()}</span>
                )}
              </div>

              <div className="overflow-hidden flex-1">
                <div className="font-medium truncate">{channel.name}</div>
                <div className="text-xs text-zinc-400">
                  {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
                </div>
              </div>
            </motion.button>
          )
        })}
      </div>
    </div>
  )
}
