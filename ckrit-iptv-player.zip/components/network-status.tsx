"use client"

import { Wifi, WifiOff } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

interface NetworkStatusProps {
  isOnline: boolean
}

export default function NetworkStatus({ isOnline }: NetworkStatusProps) {
  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {isOnline ? (
          <motion.div
            key="online"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className={cn("flex items-center gap-1 px-2 py-1 rounded-full text-xs", "bg-green-500/10 text-green-500")}
          >
            <Wifi className="h-3 w-3" />
            <span className="hidden sm:inline">Online</span>
          </motion.div>
        ) : (
          <motion.div
            key="offline"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded-full text-xs",
              "bg-red-500/10 text-red-500 animate-pulse",
            )}
          >
            <WifiOff className="h-3 w-3" />
            <span className="hidden sm:inline">Offline</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
