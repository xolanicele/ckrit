"use client"

import { Loader2, Tv2 } from "lucide-react"
import { motion } from "framer-motion"

export default function LoadingScreen() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-black via-zinc-900 to-black">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", damping: 15, stiffness: 200 }}
        className="flex flex-col items-center"
      >
        <div className="relative mb-8">
          <Tv2 className="w-20 h-20 text-purple-500" />
          <motion.div
            className="absolute inset-0 rounded-full border-4 border-t-purple-500 border-r-transparent border-b-transparent border-l-transparent"
            animate={{ rotate: 360 }}
            transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          />
        </div>

        <motion.h1
          className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Mjeyi&apos;s IPTV Services
        </motion.h1>

        <motion.div
          className="flex items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Loader2 className="w-5 h-5 animate-spin text-purple-500" />
          <p className="text-zinc-400">Loading channels...</p>
        </motion.div>
      </motion.div>
    </div>
  )
}
