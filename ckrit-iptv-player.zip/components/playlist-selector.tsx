"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { motion } from "framer-motion"
import type { Playlist } from "@/lib/types"
import { ListMusic } from "lucide-react"

interface PlaylistSelectorProps {
  playlists: Playlist[]
  selectedPlaylist: Playlist | null
  onPlaylistChange: (playlist: Playlist) => void
}

export default function PlaylistSelector({ playlists, selectedPlaylist, onPlaylistChange }: PlaylistSelectorProps) {
  if (!playlists.length) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 300, delay: 0.1 }}
      className="px-4 py-3 border-b border-zinc-800/50"
    >
      <div className="flex items-center gap-2 mb-2">
        <ListMusic className="h-4 w-4 text-purple-500" />
        <span className="text-sm font-medium text-zinc-400">Playlist Source</span>
      </div>

      <Select
        value={selectedPlaylist?.id}
        onValueChange={(value) => {
          const playlist = playlists.find((p) => p.id === value)
          if (playlist) onPlaylistChange(playlist)
        }}
      >
        <SelectTrigger className="w-full bg-zinc-900 border-zinc-800">
          <SelectValue placeholder="Select playlist" />
        </SelectTrigger>
        <SelectContent className="bg-zinc-900 border-zinc-800">
          {playlists.map((playlist) => (
            <SelectItem key={playlist.id} value={playlist.id}>
              {playlist.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </motion.div>
  )
}
