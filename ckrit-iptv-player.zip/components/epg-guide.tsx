"use client"

import { X } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import type { Channel } from "@/lib/types"
import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { format, addHours, startOfHour } from "date-fns"

interface EPGGuideProps {
  onClose: () => void
  selectedChannel: Channel | null
  onChannelSelect: (channel: Channel) => void
  channels: Channel[]
}

interface Program {
  id: string
  title: string
  description?: string
  startTime: Date
  endTime: Date
  channelId: string
}

export default function EPGGuide({ onClose, selectedChannel, onChannelSelect, channels }: EPGGuideProps) {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [programs, setPrograms] = useState<Program[]>([])
  const [loading, setLoading] = useState(true)

  // Generate mock EPG data
  useEffect(() => {
    setLoading(true)

    // This would normally fetch from an EPG API
    // For demo purposes, we'll generate mock data
    const mockPrograms: Program[] = []
    const now = startOfHour(new Date())

    channels.slice(0, 20).forEach((channel) => {
      // Generate 24 hours of programming
      for (let i = 0; i < 24; i++) {
        const startTime = addHours(now, i)
        const endTime = addHours(startTime, 1)

        mockPrograms.push({
          id: `${channel.id}-${i}`,
          title: generateProgramTitle(channel, i),
          description: "Program description would appear here. This is placeholder text for demonstration purposes.",
          startTime,
          endTime,
          channelId: channel.id,
        })
      }
    })

    setPrograms(mockPrograms)
    setLoading(false)
  }, [channels])

  // Update current time every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)

    return () => clearInterval(interval)
  }, [])

  // Generate a mock program title based on channel and time slot
  function generateProgramTitle(channel: Channel, hourOffset: number): string {
    const categories = ["News", "Sports", "Movie", "Documentary", "Kids", "Reality", "Talk Show", "Game Show"]

    const titles = [
      "The World Today",
      "Live Match",
      "Blockbuster",
      "Wild Nature",
      "Cartoon Time",
      "Celebrity House",
      "Late Night",
      "Who Wants to Win",
    ]

    const category = channel.category || categories[hourOffset % categories.length]
    const title = titles[hourOffset % titles.length]

    return `${category}: ${title} ${hourOffset % 3 === 0 ? "Live" : ""}`
  }

  // Get programs for a specific channel
  const getChannelPrograms = (channelId: string) => {
    return programs.filter((program) => program.channelId === channelId)
  }

  // Check if a program is currently airing
  const isCurrentProgram = (program: Program) => {
    return currentTime >= program.startTime && currentTime < program.endTime
  }

  // Get the current program for a channel
  const getCurrentProgram = (channelId: string) => {
    return programs.find((program) => program.channelId === channelId && isCurrentProgram(program))
  }

  // Format time for display
  const formatTime = (date: Date) => {
    return format(date, "h:mm a")
  }

  // Generate time slots for the EPG header
  const timeSlots = Array.from({ length: 6 }, (_, i) => {
    const time = addHours(startOfHour(currentTime), i)
    return {
      time,
      label: formatTime(time),
    }
  })

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 bg-black/90 backdrop-blur-md z-40 overflow-hidden flex flex-col"
    >
      <div className="p-4 border-b border-zinc-800/50 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Program Guide</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500 mx-auto mb-4"></div>
            <p className="text-zinc-400">Loading program guide...</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-hidden">
          <div className="flex border-b border-zinc-800/50">
            <div className="w-48 flex-shrink-0 p-3 border-r border-zinc-800/50">
              <p className="text-sm font-medium text-zinc-400">Channels</p>
            </div>
            <div className="flex-1 overflow-x-auto">
              <div className="flex min-w-[600px]">
                {timeSlots.map((slot, i) => (
                  <div key={i} className="flex-1 p-3 text-center">
                    <p className="text-sm font-medium text-zinc-400">{slot.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="overflow-y-auto h-full">
            {channels.slice(0, 20).map((channel) => {
              const currentProgram = getCurrentProgram(channel.id)

              return (
                <div
                  key={channel.id}
                  className={cn(
                    "flex border-b border-zinc-800/50 hover:bg-zinc-900/50 transition-colors",
                    selectedChannel?.id === channel.id && "bg-zinc-800/50",
                  )}
                >
                  <div
                    className="w-48 flex-shrink-0 p-3 border-r border-zinc-800/50 cursor-pointer"
                    onClick={() => {
                      onChannelSelect(channel)
                      onClose()
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-zinc-800 rounded overflow-hidden flex items-center justify-center">
                        {channel.logo ? (
                          <img
                            src={channel.logo || "/placeholder.svg"}
                            alt={channel.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=32&width=32"
                            }}
                          />
                        ) : (
                          <span className="text-xs font-bold">{channel.name.substring(0, 2).toUpperCase()}</span>
                        )}
                      </div>
                      <div className="overflow-hidden">
                        <p className="font-medium truncate">{channel.name}</p>
                        {currentProgram && <p className="text-xs text-zinc-400 truncate">{currentProgram.title}</p>}
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 overflow-x-auto">
                    <div className="flex min-w-[600px] h-full">
                      {getChannelPrograms(channel.id)
                        .filter((program) => {
                          // Only show programs in the next 6 hours
                          const sixHoursFromNow = addHours(currentTime, 6)
                          return program.startTime < sixHoursFromNow && program.endTime > currentTime
                        })
                        .map((program) => {
                          // Calculate width based on duration
                          const durationHours =
                            (program.endTime.getTime() - program.startTime.getTime()) / (1000 * 60 * 60)
                          const widthPercentage = (durationHours / 6) * 100

                          return (
                            <div
                              key={program.id}
                              className={cn(
                                "h-full p-2 border-r border-zinc-800/30",
                                isCurrentProgram(program) ? "bg-purple-900/20" : "bg-zinc-900/20",
                              )}
                              style={{ width: `${widthPercentage}%` }}
                            >
                              <p className="text-sm font-medium truncate">{program.title}</p>
                              <p className="text-xs text-zinc-400">
                                {formatTime(program.startTime)} - {formatTime(program.endTime)}
                              </p>
                            </div>
                          )
                        })}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </motion.div>
  )
}
