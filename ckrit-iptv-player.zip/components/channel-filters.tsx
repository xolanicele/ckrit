"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { motion } from "framer-motion"

interface ChannelFiltersProps {
  categories: string[]
  countries: string[]
  selectedCategory: string
  selectedCountry: string
  onCategoryChange: (category: string) => void
  onCountryChange: (country: string) => void
}

export default function ChannelFilters({
  categories,
  countries,
  selectedCategory,
  selectedCountry,
  onCategoryChange,
  onCountryChange,
}: ChannelFiltersProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 300 }}
      className="p-4 border-b border-zinc-800/50 space-y-4"
    >
      <div className="space-y-2">
        <label className="text-sm font-medium text-zinc-400">Category</label>
        <Select value={selectedCategory} onValueChange={onCategoryChange}>
          <SelectTrigger className="w-full bg-zinc-900 border-zinc-800">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-zinc-400">Country</label>
        <Select value={selectedCountry} onValueChange={onCountryChange}>
          <SelectTrigger className="w-full bg-zinc-900 border-zinc-800">
            <SelectValue placeholder="Select country" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            {countries.map((country) => (
              <SelectItem key={country} value={country}>
                {country}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Button
        variant="outline"
        className="w-full bg-zinc-900 border-zinc-800 hover:bg-zinc-800"
        onClick={() => {
          onCategoryChange("All")
          onCountryChange("All")
        }}
      >
        Reset Filters
      </Button>
    </motion.div>
  )
}
