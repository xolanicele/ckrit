"use client"

import type { Channel } from "@/lib/types"
import { Heart } from "lucide-react"
import { motion } from "framer-motion"
import ChannelList from "./channel-list"

interface FavoritesProps {
  channels: Channel[]
  favorites: string[]
  selectedChannel: Channel | null
  onChannelSelect: (channel: Channel) => void
  onToggleFavorite: (channelId: string) => void
}

export default function Favorites({
  channels,
  favorites,
  selectedChannel,
  onChannelSelect,
  onToggleFavorite,
}: FavoritesProps) {
  const favoriteChannels = channels.filter((channel) => favorites.includes(channel.id))

  if (favoriteChannels.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: "spring" }}
          className="flex flex-col items-center"
        >
          <Heart className="h-16 w-16 text-zinc-700 mb-4" />
          <h3 className="text-lg font-medium mb-2">No favorites yet</h3>
          <p className="text-sm text-zinc-400 max-w-xs">
            Click the heart icon on any channel to add it to your favorites for quick access
          </p>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <ChannelList
        channels={favoriteChannels}
        selectedChannel={selectedChannel}
        onChannelSelect={onChannelSelect}
        favorites={favorites}
        onToggleFavorite={onToggleFavorite}
      />
    </div>
  )
}
