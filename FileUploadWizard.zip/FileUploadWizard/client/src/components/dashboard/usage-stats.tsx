import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface UsageStat {
  label: string;
  used: number;
  total: number;
  color: string;
}

export function UsageStats() {
  // In a real app, this would be fetched from an API
  const stats: UsageStat[] = [
    {
      label: "CV Exports",
      used: 2,
      total: 5,
      color: "bg-blue-600"
    },
    {
      label: "PDF Extractions",
      used: 3,
      total: 3,
      color: "bg-purple-600"
    },
    {
      label: "AI Image Generation",
      used: 0,
      total: 2,
      color: "bg-green-600"
    },
    {
      label: "Reports",
      used: 0,
      total: 1,
      color: "bg-orange-600"
    }
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between border-b border-neutral-200 px-6 py-4">
        <CardTitle className="text-base font-bold">Usage Stats</CardTitle>
        <span className="text-xs px-2 py-1 bg-neutral-100 rounded-full">Free Plan</span>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {stats.map((stat) => (
          <div key={stat.label}>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">{stat.label}</span>
              <span className="text-sm text-neutral-500">{stat.used}/{stat.total}</span>
            </div>
            <Progress 
              value={(stat.used / stat.total) * 100} 
              className="h-2 bg-neutral-100"
              indicatorClassName={stat.color}
            />
          </div>
        ))}
        
        <Link href="/billing">
          <Button className="w-full bg-primary hover:bg-primary/90">
            Upgrade Plan
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
