import { Link } from "wouter";

export function UpgradeBanner() {
  return (
    <div className="bg-gradient-to-r from-primary to-blue-700 rounded-lg text-white p-6 mb-8 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div className="mb-4 md:mb-0">
          <h2 className="text-xl font-bold mb-2">Upgrade to Pro</h2>
          <p className="text-blue-100 max-w-lg">Get unlimited CV exports, advanced AI features, and premium templates with our Pro plan.</p>
        </div>
        <Link href="/billing">
          <button className="bg-white text-primary font-medium px-6 py-2 rounded-md hover:bg-opacity-90 transition-colors shadow-sm">
            View Plans
          </button>
        </Link>
      </div>
    </div>
  );
}
