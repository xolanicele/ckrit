import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PenLine, Layout } from "lucide-react";
import { Link } from "wouter";

export function FeaturesPreview() {
  return (
    <div className="mt-8">
      <h2 className="text-xl font-bold font-sans mb-4">Explore Premium Features</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* AI Writing Assistant */}
        <Card className="overflow-hidden flex flex-col">
          <CardContent className="p-6 flex-1">
            <div className="flex items-start">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                <PenLine className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-bold mb-2">AI Writing Assistant</h3>
                <p className="text-neutral-500 mb-4">Our AI can help you write compelling job descriptions, personal statements, and cover letters.</p>
                <div className="bg-neutral-50 rounded-md p-4 border border-neutral-200">
                  <p className="text-sm text-neutral-500 italic mb-2">"I need help writing a personal statement for a software developer position..."</p>
                  <div className="flex items-center text-neutral-400">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    <span className="text-xs">Unlock with Pro Plan</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-neutral-200 p-4 bg-neutral-50">
            <Link href="/billing" className="w-full">
              <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-white">
                Learn More
              </Button>
            </Link>
          </CardFooter>
        </Card>
        
        {/* CV Templates */}
        <Card className="overflow-hidden flex flex-col">
          <CardContent className="p-6 flex-1">
            <div className="flex items-start">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                <Layout className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-bold mb-2">Premium CV Templates</h3>
                <p className="text-neutral-500 mb-4">Access 20+ professionally designed CV templates to make your application stand out.</p>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-neutral-100 rounded-md aspect-[3/4] flex items-center justify-center">
                    <span className="text-xs text-neutral-500">Basic</span>
                  </div>
                  <div className="bg-neutral-100 rounded-md aspect-[3/4] flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-neutral-800 bg-opacity-50 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    <span className="text-xs text-neutral-500">Pro</span>
                  </div>
                  <div className="bg-neutral-100 rounded-md aspect-[3/4] flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-neutral-800 bg-opacity-50 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    <span className="text-xs text-neutral-500">Pro</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-neutral-200 p-4 bg-neutral-50">
            <Link href="/billing" className="w-full">
              <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-white">
                Learn More
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
