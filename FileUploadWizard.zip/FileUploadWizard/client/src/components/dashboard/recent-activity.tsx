import { FileTextIcon, DownloadIcon, FileDigit } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Activity {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  icon: JSX.Element;
  iconBgColor: string;
}

export function RecentActivity() {
  // In a real app, this would be fetched from an API
  const activities: Activity[] = [
    {
      id: "1",
      title: "CV Created: \"Professional Resume\"",
      description: "You created a new CV using the Professional template",
      timestamp: "Today, 10:30 AM",
      icon: <FileTextIcon className="text-blue-600" />,
      iconBgColor: "bg-blue-100"
    },
    {
      id: "2",
      title: "CV Exported",
      description: "You exported \"Professional Resume\" as PDF",
      timestamp: "Today, 10:32 AM",
      icon: <DownloadIcon className="text-green-600" />,
      iconBgColor: "bg-green-100"
    },
    {
      id: "3",
      title: "PDF Extracted",
      description: "You extracted data from \"invoice_2023.pdf\"",
      timestamp: "Yesterday, 3:45 PM",
      icon: <FileDigit className="text-purple-600" />,
      iconBgColor: "bg-purple-100"
    }
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between border-b border-neutral-200 px-6 py-4">
        <CardTitle className="text-base font-bold">Recent Activity</CardTitle>
        <button className="text-primary text-sm font-medium">View All</button>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {activities.map((activity, index) => (
            <div key={activity.id} className="flex">
              <div className="flex flex-col items-center mr-4">
                <div className={`w-8 h-8 ${activity.iconBgColor} rounded-full flex items-center justify-center`}>
                  {activity.icon}
                </div>
                {index < activities.length - 1 && (
                  <div className="flex-1 w-px bg-neutral-200 my-2"></div>
                )}
              </div>
              <div>
                <p className="font-medium">{activity.title}</p>
                <p className="text-sm text-neutral-500 mb-1">{activity.description}</p>
                <span className="text-xs text-neutral-400">{activity.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
