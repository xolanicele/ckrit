import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { 
  FileText, 
  FileDigit, 
  BarChart, 
  Bot 
} from "lucide-react";

interface QuickAction {
  title: string;
  description: string;
  icon: JSX.Element;
  href: string;
  color: string;
  bgColor: string;
}

export function QuickActions() {
  const actions: QuickAction[] = [
    {
      title: "Create New CV",
      description: "Build a professional CV with our templates",
      icon: <FileText className="text-xl" />,
      href: "/cv-maker",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      title: "Extract PDF Data",
      description: "Extract text and data from PDF files",
      icon: <FileDigit className="text-xl" />,
      href: "/pdf-extractor",
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      title: "Generate Report",
      description: "Create detailed reports from your data",
      icon: <BarChart className="text-xl" />,
      href: "/report-generator",
      color: "text-orange-600",
      bgColor: "bg-orange-100"
    },
    {
      title: "AI Studio",
      description: "Use AI to enhance your content",
      icon: <Bot className="text-xl" />,
      href: "/ai-studio",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ];

  return (
    <div>
      <h2 className="text-xl font-bold font-sans mb-4">Quick Actions</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {actions.map((action) => (
          <Link key={action.href} href={action.href}>
            <div className="bg-white rounded-lg border border-neutral-200 p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex flex-col items-center text-center">
                <div className={cn("w-12 h-12 rounded-full flex items-center justify-center mb-3", action.bgColor)}>
                  <div className={action.color}>{action.icon}</div>
                </div>
                <h3 className="font-medium mb-1">{action.title}</h3>
                <p className="text-sm text-neutral-500">{action.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
