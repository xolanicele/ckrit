import { Link, useLocation } from "wouter";
import { LayoutDashboard, FileText, FileDigit, Bot } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  icon: JSX.Element;
  label: string;
  href: string;
}

export function MobileNavigation() {
  const [location] = useLocation();
  
  const navItems: NavItem[] = [
    { icon: <LayoutDashboard className="text-xl" />, label: "Dashboard", href: "/" },
    { icon: <FileText className="text-xl" />, label: "CV Maker", href: "/cv-maker" },
    { icon: <FileDigit className="text-xl" />, label: "PDF", href: "/pdf-extractor" },
    { icon: <Bot className="text-xl" />, label: "AI Studio", href: "/ai-studio" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 px-2 py-3 z-10">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center",
              location === item.href ? "text-primary" : "text-neutral-500"
            )}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
