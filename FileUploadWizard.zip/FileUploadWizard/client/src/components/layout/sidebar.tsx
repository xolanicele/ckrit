import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  FileText, 
  FileDigit, 
  BarChart, 
  Bot, 
  User, 
  CreditCard, 
  Settings, 
  LogOut 
} from "lucide-react";

interface NavItem {
  icon: JSX.Element;
  label: string;
  href: string;
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const mainNavItems: NavItem[] = [
    { icon: <LayoutDashboard className="mr-3 h-5 w-5" />, label: "Dashboard", href: "/" },
    { icon: <FileText className="mr-3 h-5 w-5" />, label: "CV Maker", href: "/cv-maker" },
    { icon: <FileDigit className="mr-3 h-5 w-5" />, label: "PDF Extractor", href: "/pdf-extractor" },
    { icon: <BarChart className="mr-3 h-5 w-5" />, label: "Report Generator", href: "/report-generator" },
    { icon: <Bot className="mr-3 h-5 w-5" />, label: "AI Studio", href: "/ai-studio" },
  ];

  const accountNavItems: NavItem[] = [
    { icon: <User className="mr-3 h-5 w-5" />, label: "Profile", href: "/profile" },
    { icon: <CreditCard className="mr-3 h-5 w-5" />, label: "Billing", href: "/billing" },
    { icon: <Settings className="mr-3 h-5 w-5" />, label: "Settings", href: "/settings" },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 bg-white border-r border-neutral-200 h-full">
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-primary rounded mr-2 flex items-center justify-center text-white">
            <User className="h-5 w-5" />
          </div>
          <h1 className="text-xl font-bold font-sans text-neutral-800">Ckrit Platform</h1>
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto pt-4">
        <div className="px-4 mb-2 text-xs font-medium text-neutral-500 uppercase">Main</div>
        {mainNavItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center px-4 py-3 text-neutral-600 hover:bg-neutral-100",
              location === item.href && "bg-blue-50 text-primary border-l-2 border-primary"
            )}
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}
        
        <div className="mt-6 px-4 mb-2 text-xs font-medium text-neutral-500 uppercase">Account</div>
        {accountNavItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center px-4 py-3 text-neutral-600 hover:bg-neutral-100",
              location === item.href && "bg-blue-50 text-primary border-l-2 border-primary"
            )}
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-neutral-200">
        <button 
          onClick={handleLogout} 
          className="flex items-center w-full text-neutral-600 hover:text-neutral-800"
        >
          <div className="w-8 h-8 bg-neutral-200 rounded-full mr-2 flex items-center justify-center">
            <span className="text-sm font-medium">
              {user?.displayName?.[0] || user?.username?.[0] || "U"}
            </span>
          </div>
          <div>
            <p className="text-sm font-medium">{user?.displayName || user?.username}</p>
            <p className="text-xs text-neutral-500">{user?.plan || 'Free Plan'}</p>
          </div>
          <LogOut className="ml-auto h-4 w-4 text-neutral-400" />
        </button>
      </div>
    </aside>
  );
}
