import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { ProtectedRoute } from "./lib/protected-route";
import Dashboard from "@/pages/dashboard";
import AuthPage from "@/pages/auth-page";
import CVMaker from "@/pages/cv-maker";
import PDFExtractor from "@/pages/pdf-extractor";
import ReportGenerator from "@/pages/report-generator";
import AIStudio from "@/pages/ai-studio";
import Profile from "@/pages/profile";
import Billing from "@/pages/billing";
import Settings from "@/pages/settings";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/cv-maker" component={CVMaker} />
      <ProtectedRoute path="/pdf-extractor" component={PDFExtractor} />
      <ProtectedRoute path="/report-generator" component={ReportGenerator} />
      <ProtectedRoute path="/ai-studio" component={AIStudio} />
      <ProtectedRoute path="/profile" component={Profile} />
      <ProtectedRoute path="/billing" component={Billing} />
      <ProtectedRoute path="/settings" component={Settings} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
