import { AppShell } from "@/components/layout/app-shell";
import { UpgradeBanner } from "@/components/dashboard/upgrade-banner";
import { QuickActions } from "@/components/dashboard/quick-actions";
import { RecentActivity } from "@/components/dashboard/recent-activity";
import { UsageStats } from "@/components/dashboard/usage-stats";
import { FeaturesPreview } from "@/components/dashboard/features-preview";
import { useAuth } from "@/hooks/use-auth";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <AppShell>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold font-sans mb-2">
            Welcome back, {user?.displayName || user?.username || "User"}!
          </h1>
          <p className="text-neutral-500">Here's what's happening with your account today.</p>
        </div>

        <UpgradeBanner />
        <QuickActions />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RecentActivity />
          </div>
          <div>
            <UsageStats />
          </div>
        </div>

        <FeaturesPreview />
      </div>
    </AppShell>
  );
}
