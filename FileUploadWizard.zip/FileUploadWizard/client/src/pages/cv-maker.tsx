import { AppShell } from "@/components/layout/app-shell";

export default function CVMaker() {
  return (
    <AppShell>
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">CV Maker</h1>
        <div className="bg-white p-6 rounded-lg border border-neutral-200 shadow-sm">
          <p className="text-lg text-center py-12">CV Maker functionality will be implemented here</p>
        </div>
      </div>
    </AppShell>
  );
}
