import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // CV routes
  app.get("/api/cvs", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const cvs = await storage.getCVsByUserId(req.user.id);
    res.json(cvs);
  });

  app.post("/api/cvs", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const cv = await storage.createCV({
      ...req.body,
      userId: req.user.id,
      createdAt: new Date(),
    });
    res.status(201).json(cv);
  });

  app.get("/api/cvs/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const cv = await storage.getCVById(parseInt(req.params.id));
    
    if (!cv) {
      return res.status(404).json({ message: "CV not found" });
    }
    
    if (cv.userId !== req.user.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    res.json(cv);
  });

  // PDF Extractor routes
  app.post("/api/pdf/extract", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Here we would implement PDF extraction using a library like pdf-parse
    // For now, we'll just return a mock response
    res.json({
      message: "PDF extraction feature will be implemented here",
    });
  });

  // Report Generator routes
  app.post("/api/reports", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const report = await storage.createReport({
      ...req.body,
      userId: req.user.id,
      status: "pending",
      createdAt: new Date(),
    });
    
    res.status(201).json(report);
  });

  app.get("/api/reports", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const reports = await storage.getReportsByUserId(req.user.id);
    res.json(reports);
  });

  // AI Studio routes
  app.post("/api/ai/text", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Here we would implement AI text generation using OpenAI or similar
    // For now, we'll just return a mock response
    res.json({
      message: "AI text generation feature will be implemented here",
    });
  });

  app.post("/api/ai/image", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Here we would implement AI image generation using OpenAI or similar
    // For now, we'll just return a mock response
    res.json({
      message: "AI image generation feature will be implemented here",
    });
  });

  // Usage stats routes
  app.get("/api/usage-stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const usageStats = await storage.getUsageStatsByUserId(req.user.id);
    res.json(usageStats);
  });

  const httpServer = createServer(app);

  return httpServer;
}
