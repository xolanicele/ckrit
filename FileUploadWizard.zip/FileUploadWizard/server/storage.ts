import { 
  users, 
  cvs, 
  reports, 
  usageStats,
  type User, 
  type InsertUser,
  type CV,
  type InsertCV,
  type Report,
  type InsertReport,
  type UsageStat
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  
  // CV operations
  getCVById(id: number): Promise<CV | undefined>;
  getCVsByUserId(userId: number): Promise<CV[]>;
  createCV(cv: InsertCV): Promise<CV>;
  updateCV(id: number, cvData: Partial<CV>): Promise<CV | undefined>;
  deleteCV(id: number): Promise<boolean>;
  
  // Report operations
  getReportById(id: number): Promise<Report | undefined>;
  getReportsByUserId(userId: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, reportData: Partial<Report>): Promise<Report | undefined>;
  
  // Usage stats
  getUsageStatsByUserId(userId: number): Promise<UsageStat | undefined>;
  updateUsageStats(userId: number, statsData: Partial<UsageStat>): Promise<UsageStat | undefined>;
  
  // Session storage
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cvs: Map<number, CV>;
  private reports: Map<number, Report>;
  private usageStats: Map<number, UsageStat>;
  sessionStore: session.SessionStore;
  currentUserId: number;
  currentCvId: number;
  currentReportId: number;

  constructor() {
    this.users = new Map();
    this.cvs = new Map();
    this.reports = new Map();
    this.usageStats = new Map();
    this.currentUserId = 1;
    this.currentCvId = 1;
    this.currentReportId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...userData, 
      id, 
      plan: userData.plan || "Free",
      createdAt: userData.createdAt || now,
      updatedAt: now
    };
    this.users.set(id, user);
    
    // Initialize usage stats for the new user
    this.usageStats.set(id, {
      userId: id,
      cvExports: 0,
      cvExportsLimit: 5,
      pdfExtractions: 0,
      pdfExtractionsLimit: 3,
      aiImageGenerations: 0,
      aiImageGenerationsLimit: 2,
      reports: 0,
      reportsLimit: 1,
      updatedAt: now
    });
    
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      ...userData, 
      updatedAt: new Date() 
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // CV operations
  async getCVById(id: number): Promise<CV | undefined> {
    return this.cvs.get(id);
  }

  async getCVsByUserId(userId: number): Promise<CV[]> {
    return Array.from(this.cvs.values())
      .filter(cv => cv.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createCV(cvData: InsertCV): Promise<CV> {
    const id = this.currentCvId++;
    const now = new Date();
    const cv: CV = { 
      ...cvData, 
      id,
      createdAt: cvData.createdAt || now,
      updatedAt: now
    };
    this.cvs.set(id, cv);
    return cv;
  }

  async updateCV(id: number, cvData: Partial<CV>): Promise<CV | undefined> {
    const cv = this.cvs.get(id);
    if (!cv) return undefined;
    
    const updatedCV = { 
      ...cv, 
      ...cvData, 
      updatedAt: new Date() 
    };
    this.cvs.set(id, updatedCV);
    return updatedCV;
  }

  async deleteCV(id: number): Promise<boolean> {
    return this.cvs.delete(id);
  }
  
  // Report operations
  async getReportById(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getReportsByUserId(userId: number): Promise<Report[]> {
    return Array.from(this.reports.values())
      .filter(report => report.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createReport(reportData: InsertReport): Promise<Report> {
    const id = this.currentReportId++;
    const now = new Date();
    const report: Report = { 
      ...reportData, 
      id,
      createdAt: reportData.createdAt || now,
      updatedAt: now
    };
    this.reports.set(id, report);
    
    // Update usage stats
    const stats = this.usageStats.get(reportData.userId);
    if (stats) {
      stats.reports += 1;
      stats.updatedAt = now;
      this.usageStats.set(reportData.userId, stats);
    }
    
    return report;
  }

  async updateReport(id: number, reportData: Partial<Report>): Promise<Report | undefined> {
    const report = this.reports.get(id);
    if (!report) return undefined;
    
    const updatedReport = { 
      ...report, 
      ...reportData, 
      updatedAt: new Date() 
    };
    this.reports.set(id, updatedReport);
    return updatedReport;
  }
  
  // Usage stats operations
  async getUsageStatsByUserId(userId: number): Promise<UsageStat | undefined> {
    return this.usageStats.get(userId);
  }

  async updateUsageStats(userId: number, statsData: Partial<UsageStat>): Promise<UsageStat | undefined> {
    const stats = this.usageStats.get(userId);
    if (!stats) return undefined;
    
    const updatedStats = { 
      ...stats, 
      ...statsData, 
      updatedAt: new Date() 
    };
    this.usageStats.set(userId, updatedStats);
    return updatedStats;
  }
}

export const storage = new MemStorage();
