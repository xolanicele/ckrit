import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  email: text("email"),
  plan: text("plan").default("Free"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  email: true,
  plan: true,
  createdAt: true,
});

// CV schema
export const cvs = pgTable("cvs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  template: text("template").notNull(),
  data: json("data").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCVSchema = createInsertSchema(cvs).omit({
  id: true,
  updatedAt: true,
});

// Report schema
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull(),
  data: json("data"),
  result: json("result"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  updatedAt: true,
});

// Usage Stats schema
export const usageStats = pgTable("usage_stats", {
  userId: integer("user_id").primaryKey(),
  cvExports: integer("cv_exports").default(0),
  cvExportsLimit: integer("cv_exports_limit").default(5),
  pdfExtractions: integer("pdf_extractions").default(0),
  pdfExtractionsLimit: integer("pdf_extractions_limit").default(3),
  aiImageGenerations: integer("ai_image_generations").default(0),
  aiImageGenerationsLimit: integer("ai_image_generations_limit").default(2),
  reports: integer("reports").default(0),
  reportsLimit: integer("reports_limit").default(1),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUsageStatsSchema = createInsertSchema(usageStats).omit({
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type CV = typeof cvs.$inferSelect;
export type InsertCV = z.infer<typeof insertCVSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export type UsageStat = typeof usageStats.$inferSelect;
export type InsertUsageStat = z.infer<typeof insertUsageStatsSchema>;
